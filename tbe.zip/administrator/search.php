<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	$message="";
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language	
	//remove a hotel if the delete variable is set to a hotel id
	if(isset($_GET['delete'])){
		$query="SELECT * FROM cities JOIN hotel ON cities.id=hotel.city_id WHERE hotel_id=".$_GET['delete'];
		$result=mysql_query($query);
		$row=mysql_fetch_array($result);
		$citiesleft=$row['numhotels']-1;
		if ($citiesleft>0){
			$query="UPDATE cities SET numhotels=".$citiesleft." WHERE city='".$row['city']."'";
			mysql_query($query);
		}else{
			$query="DELETE FROM cities WHERE city='".$row['city']."'";
			mysql_query($query);
		}
		$query="DELETE FROM book WHERE hotel_id='".$_GET['delete']."'";
		mysql_query($query);
		$query="DELETE FROM hotel WHERE hotel_id='".$_GET['delete']."'";
		mysql_query($query);
		$query="DELETE FROM hotel_facilities WHERE hotel_id='".$_GET['delete']."'";
		mysql_query($query);
		$query="DELETE FROM rates WHERE hotel_id='".$_GET['delete']."'";
		mysql_query($query);
		$query="DELETE FROM roomtypes WHERE hotel_id='".$_GET['delete']."'";
		mysql_query($query);
		$message=get_word($lang,"Hotel Removed Successfully");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">
function showResult(){
	var name=document.getElementById('name').value;
	var address=document.getElementById('address').value;
	var country=document.getElementById('country').value;
	var params = "name="+name+"&address="+address+"&country="+country+"&lang=<?php echo $lang;?>";
	http=new XMLHttpRequest();
	
	http.open("POST","livesearch.php",true);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	http.send(params);
	http.onreadystatechange = function() {//Call a function when the state changes.
		if(http.readyState == 4 && http.status == 200){
			document.getElementById("livesearch").innerHTML=http.responseText;
		}
	}

	
}
function removehotel(id){
	var answer = confirm ("<?php echo get_word($lang,'Are you sure you want to remove this hotel?');?>");
	if(answer)
		window.location="?delete="+id;		
}
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="js/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
</head>

<body>

<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="?lang=<?php echo $lang;?>" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return false;">
	<h2><?php echo get_word($lang,"Search Hotel");?></h2>
	<h4><?php echo get_word($lang,"Use the name of a hotel (or part of it), the country or the address to get detailed information or edit it.");?></h4>
	<table border="0" cellspacing="5" cellpadding="0">
		<tr>
			<td width="129"><?php echo get_word($lang,"Name");?></td>
			<td width="153">
				<input name="name" type="text" id="name" maxlength="100" autocomplete="off" onkeyup="showResult();"/>
				
			</td>
        </tr>
        <tr>
        	<td width="129"><?php echo get_word($lang,"Country");?></td>
            <td width="153">
				<select name="country" id="country" onchange="showResult();">
                	<option value="<?php echo get_word($lang,"Select");?>"><?php echo get_word($lang,"Select");?></option>
					<?php
						$query="SELECT * FROM countries";
						$result=mysql_query($query);
						echo mysql_num_rows($result);
						while(($row=mysql_fetch_array($result))!=NULL){
								echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
						}
					?>
				</select>
			</td>
        </tr>
        <tr>
            <td width="129"><?php echo get_word($lang,"Address");?></td>
			<td width="153">
				<input name="address" type="text" id="address" maxlength="40" autocomplete="off" onkeyup="showResult();"/>
			</td>
		</tr>
	</table><BR /><BR />
		<div class="messages">
			<?php echo $message; ?>
		</div>
		<CENTER><input type="submit" name="submit" id="submit" onclick="showResult();" value="<?php echo get_word($lang,"Search");?>" onClick=""></CENTER>
	</form>
	<div id="livesearch" name="livesearch"></div>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
