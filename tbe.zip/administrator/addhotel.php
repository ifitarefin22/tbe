<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$error="";
	$message="";
	$warn=0;
	//--------Add the hotel
	
	//Checks form fields
	if(isset($_POST['submit'])){
		if(!isset($_POST['city'])){
			$error=get_word($lang,"City field cannot be empty!");
		}else if(!isset($_POST['name'])){
			$error=get_word($lang,"Name field cannot be empty!");
		}else if(!isset($_POST['address'])){
			$error=get_word($lang,"Address field cannot be empty!");
		}else if((!isset($_POST['phone1']))&&(!isset($_POST['phone2']))){
			$error=get_word($lang,"At least one phone number must be specified!");
		}else if(!isset($_POST['email'])){
			$error=get_word($lang,"A contact email must be inserted!");
		}else if(!isset($_POST['hotel_description'])){
			$error=get_word($lang,"Hotel description cannot be empty!");
		}else if((!isset($_POST['facilitiesvalues']))||(strlen($_POST['facilitiesvalues'])!=23)){
			$error=get_word($lang,"An error occured. Please contact the site administrator");//error on Facilities values field
		}else if((!isset($_POST['roomtype0']))||(!isset($_POST['roomnum0']))){
			echo $_POST['roomtype0'].",".$_POST['roomnum0'];
			$error=get_word($lang,"You must specify at least one type of room for your hotel!");
		//---------------------------end of field checks
		}else if(check_hotel_exists($_POST['name'],$_POST['address'])){//checks if hotel exists
			$error=get_word($lang,"Hotel already exists!");
		}else{
		//---------------------------------ADDING HOTEL---------------------------------------
			$city_country=check_city($_POST['city'],$_POST['country']);
			if($city_country=="error")
				$error=get_word($lang,"An error occured. Please contact the site administrator.");//Country does not exist...possible javascript hack?
			$query="SELECT * FROM cities WHERE id='".$city_country['id']."'";
			$resultcity=mysql_query($query);
			$rowcity=mysql_fetch_array($resultcity);
			$newhotelnum=$rowcity['numhotels']+1;
			$query="UPDATE cities SET numhotels=".$newhotelnum." WHERE id=".$city_country['id'];
			mysql_query($query);
			$photo=array();
			$i=0;
			$j=0;
			$rooms=array();
			$roomsnum=array();
			foreach($_POST as $key=>$value){
				if(substr($key,0,8)=="roomtype"){
					if(isset($_POST['roomtype'.$i])&&$_POST['roomtype'.$i]!=""){
						$rooms[$i]=$_POST['roomtype'.$i];
						$roomsnum[$i]=$_POST['roomnum'.$i];
						$i++;
					}
					
				}
			}
			$query="INSERT INTO hotel VALUES (NULL,'".$city_country['id']."','".$city_country['country_id']."','".$_POST['name']."'";
			foreach($_FILES as $picfile=>$file){
				if(substr("$picfile",0,7)=="picture"){
					if($file['size']>2097152){
						$error=get_word($lang,"WARNING: File size limit exceeded. The exceeding pictures have been replaced with the default.");
						$query.=",'noimage.png'";
						$warn=1;
					}else if($file['type']!="image/jpeg"&&$file['type']!="image/gif"&&$file['type']!="image/png"){
						$error=get_word($lang,"WARNING: Invalid file type or empty picture field. The invalid images have been replaced with the default.");
						$query.=",'noimage.png'";
						$warn=1;
					}else{
						if(!file_exists("images/hotels/".$_POST['name'].$_POST['address']."/")){
							mkdir("images/hotels/".$_POST['name'].$_POST['address']);
						}
						move_uploaded_file($file['tmp_name'], "images/hotels/".$_POST['name'].$_POST['address']."/".$file['name']);
						$query.=",'".$_POST['name'].$_POST['address']."/".$file['name']."'";
					}
				}
			}
			$query.=",'".$_POST['address']."','".$_POST['phone1']."','".$_POST['phone2']."','".$_POST['fax']."','".$_POST['mobile']."'";
			$query.=",'".$_POST['email']."','".$_POST['hotel_description']."','".$_POST['area_description'].
			"','".$_POST['travel_description']."','".$_POST['food_description']."',0)";
			mysql_query($query);
			$query="SELECT hotel_id FROM hotel WHERE name='".$_POST['name']."' AND hotel_address='".$_POST['address']."'";
			$result=mysql_query($query);
			$row=mysql_fetch_array($result);
			$hotel_id=$row['hotel_id'];
			$query="INSERT INTO hotel_facilities VALUES ('".$hotel_id."',";
			for ($j=0;$j<23;$j++){
				$query.="'".$_POST['facilitiesvalues'][$j]."'";
				if($j!=22)
					$query.=",";
			}
			$query.=")";
			mysql_query($query);
			$query="INSERT INTO roomtypes VALUES ";
			$i=0;
			foreach ($rooms as $room){
				$roompics=array();
				$facilitiesroom=array("minibar"=>0,"bathtub"=>0,"inroomsafe"=>0,"tv"=>0,"balcony"=>0,"radio"=>0,"phone"=>0,"ac"=>0,
										"bathacc"=>0,"wc"=>0,"hairdryer"=>0,"desk"=>0,"towels"=>0,"view"=>0,"heating"=>0);
				foreach ($_POST['things'.$i] as $things){
					$facilitiesroom[$things]=1;
				}
				$facroom="";
				foreach($facilitiesroom as $key=>$value){
					$facroom.="'".$value."',";
				}
				$facroom=substr($facroom,0,strlen($facroom)-1);
				foreach($_FILES as $picfile=>$file){
				if(substr("$picfile",0,12)=="roompicture".$i){
					if($file['size']>2097152){
							$error=get_word($lang,"WARNING: File size limit exceeded. The exceeding pictures have been replaced with the default.");
							$roompics[]="'noimage.png'";
							$warn=1;
						}else if($file['type']!="image/jpeg"&&$file['type']!="image/gif"&&$file['type']!="image/png"){
							$error=get_word($lang,"WARNING: Invalid file type or empty picture field. The invalid images have been replaced with the default.");
							$roompics[]="'noimage.png'";
							$warn=1;
						}else{
							if(!file_exists("images/hotels/".$_POST['name'].$_POST['address']."/")){
								mkdir("images/hotels/".$_POST['name'].$_POST['address']);
							}
							move_uploaded_file($file['tmp_name'], "images/hotels/".$_POST['name'].$_POST['address']."/".$file['name']);
							$roompics[]="'".$_POST['name'].$_POST['address']."/".$file['name']."'";
						}
					}
				}
				$query.="('".$hotel_id."','".$roomsnum[$i]."','".$room."','".$_POST['room_description'.$i]."',".$facroom.",".$roompics[0].",".$roompics[1]."),";
				$i++;
			}
			$query=substr($query,0,strlen($query)-1);
			mysql_query($query);
			if($warn==1||$error=="")
				$message=get_word($lang,"Hotel Succesfully Added!");
				header( "Location: addrates.php?hid=".$row['hotel_id']) ;
		}
	}
	//------------------End of the hotel addition
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">

<!----Javascript for checking for empty fields icons---!>
function checkFields(){
	if(document.getElementById("city").value==""){
		alert("<?php echo get_word($lang,"City field cannot be empty!");?>");
		document.getElementById("city").focus();
		return false;
	}else if(document.getElementById("name").value==""){
		alert("<?php echo get_word($lang,"Name field cannot be empty!");?>");
		document.getElementById("name").focus();
		return false;
	}else if(document.getElementById("address").value==""){
		alert("<?php echo get_word($lang,"Address field cannot be empty!");?>");
		document.getElementById("address").focus();
		return false;
	}else if(document.getElementById("phone1").value==""&&document.getElementById("phone2").value==""){
		alert("<?php echo get_word($lang,"At least one phone number must be specified!");?>");
		document.getElementById("phone1").focus();
		return false;
	}else if(document.getElementById("email").value==""){
		alert("<?php echo get_word($lang,"A contact email must be inserted!");?>");
		document.getElementById("email").focus();
		return false;
	}else if(document.getElementById("hotel_description").value==""){
		alert("<?php echo get_word($lang,"Hotel description cannot be empty!");?>");
		document.getElementById("hotel_description").focus();
		return false;
	}else if(document.getElementById("roomtype0").value==""||document.getElementById("roomnum0").value==""){
		alert("<?php echo get_word($lang,"You must specify at least one type of room for your hotel!");?>");
		document.getElementById("roomtype0").focus();
		return false;
	}else{
		return true;
	}
}

<!----Javascript for toggling facility icons---!>
function getName(s) {
	var d = s.lastIndexOf('.');
	return s.substring(s.lastIndexOf('/') + 1);
}
function changeImage(element,position){
	var theImg = document.getElementById(element).src;
	theImg=getName(theImg);
	var values=document.getElementById("facilitiesvalues").value;
	var newdigit; 
	var finalvalue;
	var before;
	var after;
	if (theImg == element+".png") {
		document.getElementById(element).src="images/facilities/"+element+"_hover.png";
		newdigit="1";
	}else{
		document.getElementById(element).src="images/facilities/"+element+".png";
		newdigit="0";
	}
	if(position==0){
		after=values.substring(1,values.length);
		finalvalue=newdigit+after;
	}else{
		before=values.substring(0,position);
		after=values.substring(position+1,values.length);
		finalvalue=before+newdigit+after;
	}
	document.getElementById("facilitiesvalues").value = finalvalue;
}
<!----Javascript for clearing selected facility icons---!>
function clearFacilities(){
	var facilities = new Array("airport","baby","barr","beach","car_parking","alarm","Elevator","entertainment","gym","safe","internet","iron","laundry","mailbox","exchange",
							   "satellite","smoking","spa","conference","pool","heating","ac","pets");
	var i;
	for(i in facilities){
		document.getElementById(facilities[i]).src="images/facilities/"+facilities[i]+".png";
	}
	document.getElementById("facilitiesvalues").value = "00000000000000000000000";
}
function addField(){
	var doc = document;
	var r = doc.getElementById('roomsleft');
	r.innerHTML+='<hr>\
				<table>\
				<tr>\
				<td><?php echo get_word($lang,"Room Type");?></td>\
				<td><?php echo get_word($lang,"No of Rooms");?></td>\
				</tr>\
				<tr>\
				<td><input id="roomtype'+roomnum+'" type="text" name="roomtype'+roomnum+'" size="30"></td>\
				<td><input id="roomnum'+roomnum+'" type="text" name="roomnum'+roomnum+'" size="10"></td>\
				</tr>\
				</table>\
				<table>\
				<tr>\
				<td><?php echo get_word($lang,"Please write the rooms description below");?></td>\
				</tr>\
				<tr>\
				<td><textarea name="room_description'+roomnum+'" id="room_description'+roomnum+'" cols="50" rows="5"></textarea></td>\
				<td>\
				<table>\
				<tr>\
				<td width="120">\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="minibar">Mini bar\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="bathtub">Bath Tub\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="inroomsafe">In room safe\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="tv">Tv/Pay-tv\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="balcony">Balcony\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="radio">Radio\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="phone">Phone\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="ac">A/C\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="bathacc">Bath accessories\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="wc">WC\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="hairdryer">Hairdryer\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="desk">Desk\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="towels">Towels\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="view">View\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="heating">Heating\
				</td>\
				</tr>\
				</table>\
				</td>\
				</tr>\
				</table>\
				Pictures<BR>\
				<input type="file" name="roompicture'+roomnum+'1" id="roompicture'+roomnum+'1"><BR>\
				<input type="file" name="roompicture'+roomnum+'2" id="roompicture'+roomnum+'2">';
	roomnum++;
}
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="js/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
var roomnum=1;
</script>

</head>

<body>
<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="addhotel.php" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return checkFields();">
	<h2><?php echo get_word($lang,"Add a Hotel");?></h2>
	<table border="0" cellspacing="5" cellpadding="0">
		<tr>
			<td width="129"><?php echo get_word($lang,"Country");?></td>
			<td width="153">
				<select name="country" id="country">
					<?php
						$query="SELECT * FROM countries";
						$result=mysql_query($query);
						echo mysql_num_rows($result);
						while(($row=mysql_fetch_array($result))!=NULL){
							echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
						}
					?>
				</select>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"City");?></td>
			<td>
				<input name="city" type="text" id="city" maxlength="40"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Name");?></td>
			<td>
				<input name="name" type="text" id="name" maxlength="40"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Address");?></td>
			<td>
				<input name="address" type="text" id="address" maxlength="100" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Phone 1");?></td>
			<td>
				<input name="phone1" type="text" id="phone1" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Phone 2");?></td>
			<td>
				<input name="phone2" type="text" id="phone2" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td>Fax</td>
			<td>
				<input type="text" name="fax" id="fax" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Mobile Phone");?></td>
			<td>
				<input name="mobile" type="text" id="mobile" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td>Email</td>
			<td>
				<input name="email" type="text" id="email" maxlength="100" />
			</td>
		</tr>
	</table><BR /><BR />
	<div class="errors">
		<?php echo $error; ?>
	</div>
	<div class="messages">
		<?php echo $message; ?>
	</div>
	<div class="tabber">
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Description");?></h2>
			<?php echo get_word($lang,"Please write the hotel description below");?><BR>
			<textarea id="hotel_description" name="hotel_description" cols="50" rows="5"></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Rooms");?></h2>
			<div id="roomsleft">
				<table>
				<tr>
				<td><?php echo get_word($lang,"Room Type");?></td>
				<td><?php echo get_word($lang,"No of Rooms");?></td>
				</tr>
				<tr>
				<td><input id="roomtype0" type="text" name="roomtype0" size="30"></td>
				<td><input id="roomnum0" type="text" name="roomnum0" size="10"></td>
				</tr>
				</table>
				<table>
				<tr>
				<td><?php echo get_word($lang,"Please write the rooms description below");?></td>
				</tr>
				<tr>
				<td><textarea name="room_description0" id="room_description0" cols="50" rows="5"></textarea></td>
				<td>
				<table>
				<tr>
				<td width="120">
				<input type="checkbox" id="things0[]" name="things0[]" value="minibar">Mini bar
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="bathtub">Bath Tub
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="inroomsafe">In room safe
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="tv">Tv/Pay-tv
				</td>
				</tr>
				<tr>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="balcony">Balcony
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="radio">Radio
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="phone">Phone
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="ac">A/C
				</td>
				</tr>
				<tr>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="bathacc">Bath accessories
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="wc">WC
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="hairdryer">Hairdryer
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="desk">Desk
				</td>
				</tr>
				<tr>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="towels">Towels
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="view">View
				</td>
				<td>
				<input type="checkbox" id="things0[]" name="things0[]" value="heating">Heating
				</td>
				</tr>
				</table>
				</td>
				</tr>
				</table>
				Pictures<BR>
				<input type="file" name="roompicture01" id="roompicture01"><BR>
				<input type="file" name="roompicture02" id="roompicture02">
			</div>
			<span id="addmore" onclick="addField();"><?php echo get_word($lang,"Add More");?></span>
			<div style="clear:both"></div>
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Area");?></h2>
			<?php echo get_word($lang,"Please write the area description below");?><BR>
			<textarea name="area_description" id="area_description" cols="50" rows="5"></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"How to arrive");?></h2>
			<?php echo get_word($lang,"Please write the instructions for how to arrive below");?><BR>
			<textarea name="travel_description" id="travel_description" cols="50" rows="5"></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Food");?></h2>
			<?php echo get_word($lang,"Please write the meals description below");?><BR>
			<textarea name="food_description" id="food_description" cols="50" rows="5"></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Pictures");?></h2>
			<?php echo get_word($lang,"Please select up to 5 hotel pictures to upload below")."<BR>(JPG, GIF, PNG, max 2MB)";?><BR>
			<table border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td>
						<input type="file" name="picture1" id="picture1" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture2" id="picture2" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture3" id="picture3" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture4" id="picture4" />
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture5" id="picture5" />
					</td>
				</tr>
			</table>
		</div>
		<div class="tabbertab facilities">
			<h2><?php echo get_word($lang,"Facilities");?></h2>
			<?php echo get_word($lang,"Please select the available facilities below.");?><BR>
			<?php echo get_word($lang,"Selected facilities are highlighted with green color.");?><BR>
			<table border="0">
				<tr class="line1">
					<td>
						<div class="hoverbox">
							<img id="airport" src="images/facilities/airport.png" alt="Near Airport" onclick="changeImage('airport',0);"/>
							<span><?php echo get_word($lang,"Near Airport");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="baby" src="images/facilities/baby.png" alt="Baby Sitting" onclick="changeImage('baby',1);"/>
							<span><?php echo get_word($lang,"Baby Sitting");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="barr" src="images/facilities/barr.png" alt="Bar Available" onclick="changeImage('barr',2);"/>
							<span>Bar</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="beach" src="images/facilities/beach.png" alt="Near Beach" onclick="changeImage('beach',3);"/>
							<span><?php echo get_word($lang,"Near Beach");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="car_parking" src="images/facilities/car_parking.png" alt="Parking Available" onclick="changeImage('car_parking',4);"/>
							<span>Parking</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="alarm" src="images/facilities/alarm.png" alt="Alarm Service" onclick="changeImage('alarm',5);"/>
							<span><?php echo get_word($lang,"Alarm Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="Elevator" src="images/facilities/Elevator.png" alt="Elevator Available" onclick="changeImage('Elevator',7);"/>
							<span><?php echo get_word($lang,"Elevator Available");?></span>
						</div>
					</td>
				</tr>
				<tr class="line2">
					<td>
						<div class="hoverbox">
							<img id="entertainment" src="images/facilities/entertainment.png" alt="Entertainment Hall" onclick="changeImage('entertainment',8);"/>
							<span><?php echo get_word($lang,"Entertainment Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="gym" src="images/facilities/gym.png" alt="Gym facilities" onclick="changeImage('gym',9);"/>
							<span><?php echo get_word($lang,"Gym Facilities");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="safe" src="images/facilities/safe.png" alt="Safe" onclick="changeImage('safe',10);"/>
							<span><?php echo get_word($lang,"In room Safe");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="internet" src="images/facilities/internet.png" alt="Internet" onclick="changeImage('internet',11);"/>
							<span>Internet</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="iron" src="images/facilities/iron.png" alt="Iron" onclick="changeImage('iron',12);"/>
							<span><?php echo get_word($lang,"In room Iron");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="laundry" src="images/facilities/laundry.png" alt="Laundry Service" onclick="changeImage('laundry',13);"/>
							<span><?php echo get_word($lang,"Laundry Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="mailbox" src="images/facilities/mailbox.png" alt="mailbox" onclick="changeImage('mailbox',14);"/>
							<span><?php echo get_word($lang,"Mailbox");?></span>
						</div>
					</td>
				</tr>
				<tr class="line3">
					<td>
						<div class="hoverbox">
							<img id="exchange" src="images/facilities/exchange.png" alt="Money Exchange" onclick="changeImage('exchange',15);"/>
							<span><?php echo get_word($lang,"Money Exchange");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="satellite" src="images/facilities/satellite.png" alt="Satellite tv" onclick="changeImage('satellite',16);"/>
							<span><?php echo get_word($lang,"Satellite Tv");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="spa" src="images/facilities/spa.png" alt="Spa" onclick="changeImage('spa',18);"/>
							<span>Spa</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="conference" src="images/facilities/conference.png" alt="Conference Hall" onclick="changeImage('conference',6);"/>
							<span><?php echo get_word($lang,"Conference Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="pool" src="images/facilities/pool.png" alt="Swimming Pool" onclick="changeImage('pool',19);"/>
							<span><?php echo get_word($lang,"Swimming Pool");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="heating" src="images/facilities/heating.png" alt="Heating" onclick="changeImage('heating',20);"/>
							<span><?php echo get_word($lang,"Heating");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="ac" src="images/facilities/ac.png" alt="Air Conditioning" onclick="changeImage('ac',21);"/>
							<span><?php echo get_word($lang,"Air Conditioning");?></span>
						</div>
					</td>
				</tr>
			</table>
			<div class="smokepets">
				<table border=0>
					<tr>
						<td>
							<div class="hoverbox">
								<img id="pets" src="images/facilities/pets.png" alt="Pets" onclick="changeImage('pets',22);"/>
								<span><?php echo get_word($lang,"Pets Allowed");?></span>
							</div>
						</td>
						<td>
							<div class="hoverbox">
								<img id="smoking" src="images/facilities/smoking.png" alt="Smoking" onclick="changeImage('smoking',17);"/>
								<span><?php echo get_word($lang,"Smoking Allowed");?></span>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<div id="clearfacilities" onclick="clearFacilities();"><?php echo get_word($lang,"Clear Selected Facilities");?></div>
			<input type="hidden" name="facilitiesvalues" id="facilitiesvalues" value="00000000000000000000000">
		</div><BR><BR>
		<CENTER><input type="submit" name="submit" id="submit" value="<?php echo get_word($lang,"Save");?>" onClick=""><input type="button" name="cancel" id="cancel" value="<?php echo get_word($lang,"Cancel");?>" onClick="window.location='index.php'"></CENTER>
	</div>
	</form>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
