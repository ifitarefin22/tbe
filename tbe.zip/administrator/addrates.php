<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	if(!isset($_GET['hid']))
		header( 'Location: search.php' ) ;
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$error="";
	$message="";
	$warn=0;
	//--------Add the rates
	
	//Checks form fields
	if(isset($_POST['submit'])){
		
		//---------------------------------ADDING RATES---------------------------------------
			$query="DELETE FROM rates WHERE hotel_id='".$_GET['hid']."'";
			mysql_query($query);
			$query="SELECT room_type FROM roomtypes WHERE hotel_id='".$_GET['hid']."'";
			$result=mysql_query($query);
			$i=0;
			$j=0;
			$rooms=array();
			$roomsnum=array();
			$key=0;
			while($row=mysql_fetch_array($result)){
					$query="INSERT INTO rates VALUES (NULL,'".$_GET['hid']."','".$row['room_type']."','".$_POST['flatrate'.$key]."','".$_POST['monday'.$key]."','"
					.$_POST['tuesday'.$key]."','".$_POST['wednesday'.$key]."','".$_POST['thursday'.$key]."','"
					.$_POST['friday'.$key]."','".$_POST['saturday'.$key]."','".$_POST['sunday'.$key]."')";
					mysql_query($query);
				$key++;
			}
			$query="UPDATE hotel SET rates_added=1 WHERE hotel_id='".$_GET['hid']."'";
			mysql_query($query);
			$message=get_word($lang,"Hotel rates set succesfully!");
	}
	//------------------End of the hotel addition
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">
<!----Javascript for checking for empty fields icons---!>
function checkFields(){
	var i;
	var checkflag=0;
	for(i=0;i<<?php echo mysql_num_rows($result);?>;i++){
		if(document.getElementById("flatrate"+i).value==""){
			alert("<?php echo get_word($lang,"The General Rate cannot be empty!");?>");
			document.getElementById("flatrate"+i).focus();
			return false;
		}
	}
	return true;
}
</script>
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">

</head>

<body>

<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="addrates.php?hid=<?php echo $_GET['hid'];?>" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return checkFields();">
	<h2><?php echo get_word($lang,"Rates");?></h2>
	<div class="messages">
		<?php echo $message; ?>
	</div>
		<?php 
		$query="SELECT * FROM rates WHERE hotel_id='".$_GET['hid']."' ORDER BY id ASC";
		$result2=mysql_query($query);
		$rates=array();
		if(mysql_num_rows($result2)>0){
			while($row=mysql_fetch_array($result2)){
				$rates['default_price'][]=$row['default_price'];
				$rates['price_monday'][]=$row['price_monday'];
				$rates['price_tuesday'][]=$row['price_tuesday'];
				$rates['price_wednesday'][]=$row['price_wednesday'];
				$rates['price_thursday'][]=$row['price_thursday'];
				$rates['price_friday'][]=$row['price_friday'];
				$rates['price_saturday'][]=$row['price_saturday'];
				$rates['price_sunday'][]=$row['price_sunday'];
			}
		}
		$query="SELECT room_type FROM roomtypes WHERE hotel_id='".$_GET['hid']."'";
		$result=mysql_query($query);
		$key=0;
		while($row=mysql_fetch_array($result)){
				if(!isset($rates['default_price'][$key])){
					$rates['default_price'][]="";
					$rates['price_monday'][]="";
					$rates['price_tuesday'][]="";
					$rates['price_wednesday'][]="";
					$rates['price_thursday'][]="";
					$rates['price_friday'][]="";
					$rates['price_saturday'][]="";
					$rates['price_sunday'][]="";
				}
				echo "
				<h3>".get_word($lang,"Room Type").": ".$row['room_type']."</h3>
				<div id=\"ratesleft\">
					".get_word($lang,"General Rate").":<BR><BR><input type=\"text\" value=\"".$rates['default_price'][$key]."\" name=\"flatrate".$key."\" id=\"flatrate".$key."\"><BR><BR>
				
				</div>
				<div id=\"ratesright\">
					".get_word($lang,"Prices for specific days of week (leave blank if its the same everyday)").":<BR><BR>
					<table border=0 cellpadding=2 cellspacing=2>
						<tr>
							<td>
								".get_word($lang,"Monday").":
							</td>
							<td>
								<input type=\"text\" name=\"monday".$key."\" id=\"monday".$key."\" value=\"".$rates['price_monday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Tuesday").":
							</td>
							<td>
								<input type=\"text\" name=\"tuesday".$key."\" id=\"tuesday".$key."\" value=\"".$rates['price_tuesday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Wednesday").":
							</td>
							<td>
								<input type=\"text\" name=\"wednesday".$key."\" id=\"wednesday".$key."\" value=\"".$rates['price_wednesday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Thursday").":
							</td>
							<td>
								<input type=\"text\" name=\"thursday".$key."\" id=\"thursday".$key."\" value=\"".$rates['price_thursday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Friday").":
							</td>
							<td>
								<input type=\"text\" name=\"friday".$key."\" id=\"friday".$key."\" value=\"".$rates['price_friday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Saturday").":
							</td>
							<td>
								<input type=\"text\" name=\"saturday".$key."\" id=\"saturday".$key."\" value=\"".$rates['price_saturday'][$key]."\" size=\"5\">
							</td>
						</tr>
						<tr>
							<td>
								".get_word($lang,"Sunday").":
							</td>
							<td>
								<input type=\"text\" name=\"sunday".$key."\" id=\"sunday".$key."\" value=\"".$rates['price_sunday'][$key]."\" size=\"5\">
							</td>
						</tr>
					</table>
				</div>
				<div style=\"clear:both\"></div>";
			$key++;
		}
		?>
		<CENTER><input type="submit" name="submit" id="submit" value="<?php echo get_word($lang,"Save");?>" onClick=""><input type="button" name="cancel" id="cancel" value="<?php echo get_word($lang,"Cancel");?>" onClick="window.location='index.php'"></CENTER>
	</form>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
