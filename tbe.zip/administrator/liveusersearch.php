﻿<?php
session_start();
if(!isset($_SESSION['username'])){
	header("Location:login.php");
}
include "includes/configuration.php";
$con=mysql_connect($location,$username,$password);
mysql_select_db($database_name);
mysql_set_charset('utf8',$con);
include "includes/language.php";
	//Set language
	if(isset($_POST['lang'])){
		$lang=$_POST['lang'];
	}else{
		$lang="English";
	}
	//end of set language	
	
$name=$_POST['name'];
$surname=$_POST['surname'];
$username=$_POST['username'];
$conditions=array();
if(strlen($name)>0){
	$conditions[]="name LIKE '%".$name."%'";;
}
if(strlen($surname)>0){
	$conditions[]="surname LIKE '%".$surname."%'";;
}
if(strlen($username)>0){
	$conditions[]="username LIKE '%".$username."%'";;
}
$query="SELECT * FROM users WHERE";
foreach($conditions as $key=>$value){
	if($key==0)
		$query.=" ".$value;
	else
		$query.=" AND ".$value;
}
$result=mysql_query($query);
$hint="";
if (strlen($name)>0||strlen($surname)>0||strlen($username)>0){
	$i=0;
	while(($row=mysql_fetch_array($result))!=NULL){
		if(($i%2)==0)
			$class="even";
		else
			$class="odd";
		$i++;
				if ($hint==""){
					$hint="<table border=0 cellpadding=1 cellspacing=0 width=\"100\"><tr class=\"headtable\"><td>".get_word($lang,"NAME")."</td><td>".get_word($lang,"SURNAME")."</td><td>".get_word($lang,"USERNAME")."</td><td align=\"right\">".get_word($lang,"OPTIONS")."</td></tr>";
					$hint.="<tr class=\"".$class."\"><td>".$row['name']."</td><td>".$row['surname']."</td><td>".$row['username']."</td>
							<td align=\"right\"><a href=\"edituser.php?user=".$row['username']."\">".get_word($lang,"Edit User")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"#\" onclick=\"removeuser('".$row['username']."');\">".get_word($lang,"Remove User")."</a></td></tr>";
				}else{
					$hint.="<tr class=\"".$class."\"><td>".$row['name']."</td><td>".$row['surname']."</td><td>".$row['username']."</td>
							<td align=\"right\"><a href=\"edituser.php?user=".$row['username']."\">".get_word($lang,"Edit User")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"#\" onclick=\"removeuser('".$row['username']."');\">".get_word($lang,"Remove User")."</a></td></tr>";
				}
	}
}

// Set output to "no results" if no hint were found
// or to the correct values
if ($hint==""){
	$response=get_word($lang,"No results");
}
else{
	$response=$hint."</table>";
}
//output the response
echo $response;
?> 