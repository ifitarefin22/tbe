﻿<?php
session_start();
if(!isset($_SESSION['username'])){
	header("Location:login.php");
}

include "includes/configuration.php";
$con=mysql_connect($location,$username,$password);
mysql_select_db($database_name);
mysql_set_charset('utf8',$con);
include "includes/language.php";
	//Set language
	if(isset($_POST['lang'])){
		$lang=$_POST['lang'];
	}else{
		$lang="English";
	}
	//end of set language	
	
$name=$_POST['name'];
$address=$_POST['address'];
$country=$_POST['country'];
$conditions=array();
if(strlen($name)>0){
	$conditions[]="name LIKE '%".$name."%'";;
}
if($country!=get_word($lang,"Select")){
	$conditions[]="country='".$country."'";;
}
if(strlen($address)>0){
	$conditions[]="hotel_address LIKE '%".$address."%'";;
}
$query="SELECT * FROM hotel JOIN countries ON hotel.country_id=countries.id WHERE";
foreach($conditions as $key=>$value){
	if($key==0)
		$query.=" ".$value;
	else
		$query.=" AND ".$value;
}
$result=mysql_query($query);
$hint="";
if (strlen($name)>0||strlen($address)>0||$country!=get_word($lang,"Select")){
	$i=0;
	while(($row=mysql_fetch_array($result))!=NULL){
		if(($i%2)==0)
			$class="even";
		else
			$class="odd";
		$i++;
				if ($hint==""){
					$hint="<table border=0 cellpadding=1 cellspacing=0 width=\"100\"><tr class=\"headtable\"><td>".get_word($lang,"NAME")."</td><td>".get_word($lang,"ADDRESS")."</td><td>".get_word($lang,"COUNTRY")."</td><td align=\"right\">".get_word($lang,"OPTIONS")."</td></tr>";
					$hint.="<tr class=\"".$class."\"><td>".$row['name']."</td><td>".$row['hotel_address']."</td><td>".$row['country']."</td>
							<td align=\"right\"><a href=\"edithotel.php?hid=".$row['hotel_id']."\">".get_word($lang,"Edit Hotel")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"addrates.php?hid=".$row['hotel_id']."\">".get_word($lang,"Edit Rates")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".get_word($lang,"View/Edit Bookings")."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"#\" onclick=\"removehotel('".$row['hotel_id']."');\">".get_word($lang,"Remove Hotel")."</a></td></tr>";
				}else{
					$hint.="<tr class=\"".$class."\"><td>".$row['name']."</td><td>".$row['hotel_address']."</td><td>".$row['country']."</td>
							<td align=\"right\"><a href=\"edithotel.php?hid=".$row['hotel_id']."\">".get_word($lang,"Edit Hotel")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"addrates.php?hid=".$row['hotel_id']."\">".get_word($lang,"Edit Rates")."</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".get_word($lang,"View/Edit Bookings")."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"#\" onclick=\"removehotel('".$row['hotel_id']."');\">".get_word($lang,"Remove Hotel")."</a></td></tr>";
				}
	}
}

// Set output to "no results" if no hint were found
// or to the correct values
if ($hint==""){
	$response=get_word($lang,"No results");
}
else{
	$response=$hint."</table>";
}
//output the response
echo $response;
?> 