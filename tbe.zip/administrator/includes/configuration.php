<?php
$location="localhost";//database ip. usually localhost.
$database_name="grihayon_hotel1";//database name
$username="grihayon_hotel";//database username
$password="bAGGqaUZO7%H";//database password
$site_title="Hotel Portal";//title to appear in all site pages
?>
