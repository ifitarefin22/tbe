<?php
function get_word($language_name,$word){
	if($language_name=="English")
		return $word;
	include "configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_set_charset('utf8',$con);
	mysql_select_db($database_name);
	$query="SELECT id FROM languages WHERE language='".$language_name."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		return $word;
	}else{
		$id=mysql_fetch_array($result);
		$query="SELECT * FROM language WHERE lang_id='".$id['id']."' AND word='".$word."'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)==0){
			return $word;
		}else{
			$row=mysql_fetch_array($result);
			return $row['translation'];
		}
	}
	return $word;
}

?>