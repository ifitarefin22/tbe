﻿<html>
<head>
<script>
var timeout	= 0;
var closetimer	= 0;
var ddmenuitem	= 0;

// open hidden layer
function mopen(id)
{	
	// cancel close timer
	mcancelclosetime();

	// close old layer
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';

	// get new layer and show it
	ddmenuitem = document.getElementById(id);
	ddmenuitem.style.visibility = 'visible';

}
// close showed layer
function mclose()
{
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';
}

// go close timer
function mclosetime()
{
	closetimer = window.setTimeout(mclose, timeout);
}

// cancel close timer
function mcancelclosetime()
{
	if(closetimer)
	{
		window.clearTimeout(closetimer);
		closetimer = null;
	}
}

// close layer when click-out
document.onclick = mclose; 
</script>
</head>
<body>
<ul id="sddm">
    <li><a href="#" 
        onmouseover="mopen('m1')" 
        onmouseout="mclosetime()"><?php echo get_word($lang,"Hotels");?></a>
        <div id="m1" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a href="addhotel.php"><?php echo get_word($lang,"Add a Hotel");?></a>
        <a href="search.php"><?php echo get_word($lang,"Search a Hotel");?></a>
        <a href="search.php"><?php echo get_word($lang,"Edit Hotel Information/Prices");?></a>
        <a href="search.php"><?php echo get_word($lang,"Remove a Hotel");?></a>
        </div>
    </li>
	<li><a href="#" 
        onmouseover="mopen('m2')" 
        onmouseout="mclosetime()"><?php echo get_word($lang,"Bookings");?></a>
        <div id="m2" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a href="#"><?php echo get_word($lang,"View Bookings");?></a>
        <a href="#"><?php echo get_word($lang,"Edit Booking");?></a>
        <a href="#"><?php echo get_word($lang,"Add Booking");?></a>
        </div>
    </li>
	<li><a href="#" ><?php echo get_word($lang,"View/Edit Comments");?></a>
    </li>
	<li><a href="#" 
        onmouseover="mopen('m4')" 
        onmouseout="mclosetime()"><?php echo get_word($lang,"Users");?></a>
        <div id="m4" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a href="adduser.php"><?php echo get_word($lang,"Add user");?></a>
		<a href="usersearch.php"><?php echo get_word($lang,"Edit user");?></a>
		<a href="liveusersearch.php"><?php echo get_word($lang,"Remove user");?></a>
        </div>
    </li>
	<li>
		<a href="login.php" ><?php echo get_word($lang,"Logout");?></a>
	</li>
</ul>
<div style="clear:both"></div>
</body>
</html>
