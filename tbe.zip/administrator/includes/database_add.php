<?php
function check_hotel_exists($hotel_name,$address){
	$query="SELECT name FROM hotel WHERE name='".$hotel_name."' AND hotel_address='".$address."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		return false;
	}else{
		return true;
	}
	return false;
}
function check_city($city,$country){
	$query="SELECT cities.id,cities.country_id FROM countries JOIN cities ON countries.id=cities.country_id WHERE city='".$city."' AND country='".$country."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		$query="SELECT id FROM countries WHERE country='".$country."'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)==0)
			return "error";//Country does not exist...possible javascript hack?
		else{
			$row=mysql_fetch_array($result);
			$query="INSERT INTO cities VALUES (NULL,'".$row['id']."','".$city."',0)";
			$result=mysql_query($query);
			$query="SELECT id,country_id FROM cities WHERE country_id='".$row['id']."' AND city='".$city."'";
			$result=mysql_query($query);
			$row=mysql_fetch_array($result);
			return $row;
		}
		return false;
	}else{
		$row=mysql_fetch_array($result);
		return $row;
	}
}
function check_user_email($user,$email){
	$query="SELECT * FROM users WHERE username='".$user."' OR email='".$email."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0)
		return true;
	else
		return false;
}
?>