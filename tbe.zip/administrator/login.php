<?php
	session_start();
	$message="";
	unset($_SESSION['username']);
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	
	if(isset($_POST['submit'])){
		$query="SELECT * FROM users WHERE username='".$_POST['username']."' AND password='".$_POST['password']."' AND role='administrator'";
		$result=mysql_query($query);
		$row=mysql_fetch_array($result,MYSQL_ASSOC);
		if(mysql_num_rows($result)>0){
			header("Location:index.php");
			$_SESSION['username']=$row['username'];
		}else
			$message=get_word($lang,"Wrong username or password.");
	}
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<style>
	body{
		font-family:Verdana;	
		font-size:11px;
	}
	#box{
		position:absolute;
		top:50%;
		margin-top:-100px;
		left:50%;
		margin-left:-200px;
		width:400px;
		height:200px;
		border:1px solid #DEDEDE;
	}
	#title{
		border-bottom:1px solid #dedede;
		background:#5970B2;
		color:#FFF;
	}
	#form{
		text-align:center;
		padding-top:20px;
	}
	#message{
		color:red;
		padding-top:10px;
		text-align:center;
	}
	input{
		border:1px solid #dedede;
	}
	h1,h2{
		padding:0;
		margin:0;
	}
	h1{
		padding-left:10px;
	}
</style>
</head>
	<div id="box">
    	<div id="title">
        	<h1><?php echo get_word($lang,"Login");?></h1>
			<div style="position:absolute;top:3px;right:5px;" id="langselect">
				<?php include "includes/languagebar.php";?>
			</div>
        </div>
		<div id="form">
			<form name="loginform" method="post" action="login.php">
				<table style="text-align:left;margin:0 auto;">
					<tr>
						<td style="text-align:right;"><?php echo get_word($lang,"Username");?></td>
						<td><input type="text" name="username" id="username"></td>
					</tr>
						<td style="text-align:right;"><?php echo get_word($lang,"Password");?></td>
						<td><input type="password" name="password" id="password"></td>
					<tr>
					</tr>
				</table>
				<input type="submit" name="submit" id="submit" value="<?php echo get_word($lang,"Login");?>">
			</form>
		</div>
		<div id="message">
			<?php echo $message;?>
		</div>
    </div>
<body>
</body>
</html>
