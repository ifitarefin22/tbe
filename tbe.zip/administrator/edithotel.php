<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	if(!isset($_GET['hid'])){
		header("Location:search.php");
	}
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$error="";
	$message="";
	$warn=0;
	//--------Add the hotel
	
	//Checks form fields
	if(isset($_POST['submit'])){
		if(!isset($_POST['city'])){
			$error=get_word($lang,"City field cannot be empty!");
		}else if(!isset($_POST['name'])){
			$error=get_word($lang,"Name field cannot be empty!");
		}else if(!isset($_POST['address'])){
			$error=get_word($lang,"Address field cannot be empty!");
		}else if((!isset($_POST['phone1']))&&(!isset($_POST['phone2']))){
			$error=get_word($lang,"At least one phone number must be specified!");
		}else if(!isset($_POST['email'])){
			$error=get_word($lang,"A contact email must be inserted!");
		}else if(!isset($_POST['hotel_description'])){
			$error=get_word($lang,"Hotel description cannot be empty!");
		}else if((!isset($_POST['facilitiesvalues']))||(strlen($_POST['facilitiesvalues'])!=23)){
			$error=get_word($lang,"An error occured. Please contact the site administrator");//error on Facilities values field
		}else if((!isset($_POST['roomtype0']))||(!isset($_POST['roomnum0']))){
			echo $_POST['roomtype0'].",".$_POST['roomnum0'];
			$error=get_word($lang,"You must specify at least one type of room for your hotel!");
		//---------------------------end of field checks
		}else{
		//---------------------------------UPDATING HOTEL---------------------------------------
							
			$city_country=check_city($_POST['city'],$_POST['country']);
			if($city_country=="error")
				$error=get_word($lang,"An error occured. Please contact the site administrator.");//Country does not exist...possible javascript hack?
			$query="SELECT * FROM cities JOIN hotel ON hotel.city_id=cities.id WHERE hotel_id=".$_GET['hid'];
			$resultcity=mysql_query($query);
			$rowcity=mysql_fetch_array($resultcity);
			if($rowcity['city']!=$_POST['city']){
				$newhotelnum=$rowcity['numhotels']-1;
				if($newhotelnum==0){
					$query="DELETE FROM cities WHERE city='".$rowcity['city']."'";
					mysql_query($query);
				}
				$query="SELECT * FROM cities WHERE id=".$city_country['id'];
				$resultcity=mysql_query($query);
				$rowcity=mysql_fetch_array($resultcity);
				$newnum=$rowcity['numhotels']+1;
				$query="UPDATE cities SET numhotels=".$newnum." WHERE id=".$city_country['id'];
				mysql_query($query);
			}
			$i=0;
			$j=0;
			$rooms=array();
			$roomsnum=array();
			foreach($_POST as $key=>$value){
				if(substr($key,0,8)=="roomtype"){
					if(isset($_POST['roomtype'.$i])&&$_POST['roomtype'.$i]!=""){
						$rooms[$i]=$_POST['roomtype'.$i];
						$roomsnum[$i]=$_POST['roomnum'.$i];
						$i++;
					}
					
				}
			}
			$query="SELECT rates_added FROM hotel WHERE hotel_id='".$_GET['hid']."'";
			$result=mysql_query($query);
			$row=mysql_fetch_array($result);
			$rates_added=$row['rates_added'];
			$myquery="SELECT * FROM hotel WHERE hotel_id='".$_GET['hid']."'";
			$myresult=mysql_query($myquery);
			$myrow=mysql_fetch_array($myresult);
			$query="DELETE FROM hotel WHERE hotel_id='".$_GET['hid']."'";
			mysql_query($query);
			$query="INSERT INTO hotel VALUES ('".$_GET['hid']."','".$city_country['id']."','".$city_country['country_id']."','".$_POST['name']."'";
			$imgnum=1;
			foreach($_FILES as $picfile=>$file){
				if(substr("$picfile",0,7)=="picture"){
					if($file['size']>2097152){
						$error=get_word($lang,"WARNING: File size limit exceeded. The exceeding pictures have been replaced with the default.");
						$query.=",'noimage.png'";
						$warn=1;
					}else if($file['type']!="image/jpeg"&&$file['type']!="image/gif"&&$file['type']!="image/png"){
						$query.=",'".$myrow['photo'.$imgnum]."'";
					}else{
						if(!file_exists("images/hotels/".$_POST['name'].$_POST['address']."/")){
							mkdir("images/hotels/".$_POST['name'].$_POST['address']);
						}
						move_uploaded_file($file['tmp_name'], "images/hotels/".$_POST['name'].$_POST['address']."/".$file['name']);
						$query.=",'".$_POST['name'].$_POST['address']."/".$file['name']."'";
					}
					$imgnum++;
				}
				
			}
			$query.=",'".$_POST['address']."','".$_POST['phone1']."','".$_POST['phone2']."','".$_POST['fax']."','".$_POST['mobile']."'";
			$query.=",'".$_POST['email']."','".$_POST['hotel_description']."','".$_POST['area_description'].
			"','".$_POST['travel_description']."','".$_POST['food_description']."','".$rates_added."')";
			
			mysql_query($query);
			$query="SELECT hotel_id FROM hotel WHERE name='".$_POST['name']."' AND hotel_address='".$_POST['address']."'";
			$result=mysql_query($query);
			$row=mysql_fetch_array($result);
			$hotel_id=$row['hotel_id'];
			$query="DELETE FROM hotel_facilities WHERE hotel_id='".$_GET['hid']."'";
			mysql_query($query);
			$query="INSERT INTO hotel_facilities VALUES ('".$hotel_id."',";
			for ($j=0;$j<23;$j++){
				$query.="'".$_POST['facilitiesvalues'][$j]."'";
				if($j!=22)
					$query.=",";
			}
			$query.=")";
			mysql_query($query);
			$myquery="SELECT * FROM roomtypes WHERE hotel_id='".$_GET['hid']."'";
			$myresult=mysql_query($myquery);
			$query="DELETE FROM roomtypes WHERE hotel_id='".$_GET['hid']."'";
			mysql_query($query);
			$query="INSERT INTO roomtypes VALUES ";
			$i=0;
			foreach ($rooms as $room){
				$myrow=mysql_fetch_array($myresult);
				$roompics=array();
				$facilitiesroom=array("minibar"=>0,"bathtub"=>0,"inroomsafe"=>0,"tv"=>0,"balcony"=>0,"radio"=>0,"phone"=>0,"ac"=>0,
										"bathacc"=>0,"wc"=>0,"hairdryer"=>0,"desk"=>0,"towels"=>0,"view"=>0,"heating"=>0);
				foreach ($_POST['things'.$i] as $things){
					$facilitiesroom[$things]=1;
				}
				$facroom="";
				foreach($facilitiesroom as $key=>$value){
					$facroom.="'".$value."',";
				}
				$facroom=substr($facroom,0,strlen($facroom)-1);
				$imgnum=1;
				foreach($_FILES as $picfile=>$file){
				if(substr("$picfile",0,12)=="roompicture".$i){
					if($file['size']>2097152){
							$error=get_word($lang,"WARNING: File size limit exceeded. The exceeding pictures have been replaced with the default.");
							$roompics[]="'noimage.png'";
							$warn=1;
						}else if($file['type']!="image/jpeg"&&$file['type']!="image/gif"&&$file['type']!="image/png"){
							if($myrow!=NULL)
								$roompics[]="'".$myrow['picture'.$imgnum]."'";
							else
								$roompics[]="'noimage.png'";
						}else{
							if(!file_exists("images/hotels/".$_POST['name'].$_POST['address']."/")){
								mkdir("images/hotels/".$_POST['name'].$_POST['address']);
							}
							move_uploaded_file($file['tmp_name'], "images/hotels/".$_POST['name'].$_POST['address']."/".$file['name']);
							$roompics[]="'".$_POST['name'].$_POST['address']."/".$file['name']."'";
						}
					$imgnum++;
					if($imgnum>=2)
					$imgnum=1;
				}
				
				}
				$query.="('".$hotel_id."','".$roomsnum[$i]."','".$room."','".$_POST['room_description'.$i]."',".$facroom.",".$roompics[0].",".$roompics[1]."),";
				$i++;
			}
			$query=substr($query,0,strlen($query)-1);
			mysql_query($query);
			if($warn==1||$error=="")
				$message=get_word($lang,"Hotel Succesfully Edited!");
		}
	}
	//------------------End of the hotel addition
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">

<!----Javascript for checking for empty fields icons---!>
function checkFields(){
	if(document.getElementById("city").value==""){
		alert("<?php echo get_word($lang,"City field cannot be empty!");?>");
		document.getElementById("city").focus();
		return false;
	}else if(document.getElementById("name").value==""){
		alert("<?php echo get_word($lang,"Name field cannot be empty!");?>");
		document.getElementById("name").focus();
		return false;
	}else if(document.getElementById("address").value==""){
		alert("<?php echo get_word($lang,"Address field cannot be empty!");?>");
		document.getElementById("address").focus();
		return false;
	}else if(document.getElementById("phone1").value==""&&document.getElementById("phone2").value==""){
		alert("<?php echo get_word($lang,"At least one phone number must be specified!");?>");
		document.getElementById("phone1").focus();
		return false;
	}else if(document.getElementById("email").value==""){
		alert("<?php echo get_word($lang,"A contact email must be inserted!");?>");
		document.getElementById("email").focus();
		return false;
	}else if(document.getElementById("hotel_description").value==""){
		alert("<?php echo get_word($lang,"Hotel description cannot be empty!");?>");
		document.getElementById("hotel_description").focus();
		return false;
	}else if(document.getElementById("roomtype0").value==""||document.getElementById("roomnum0").value==""){
		alert("<?php echo get_word($lang,"You must specify at least one type of room for your hotel!");?>");
		document.getElementById("roomtype0").focus();
		return false;
	}else{
		return true;
	}
}

<!----Javascript for toggling facility icons---!>
function getName(s) {
	var d = s.lastIndexOf('.');
	return s.substring(s.lastIndexOf('/') + 1);
}
function changeImage(element,position){
	var theImg = document.getElementById(element).src;
	theImg=getName(theImg);
	var values=document.getElementById("facilitiesvalues").value;
	var newdigit; 
	var finalvalue;
	var before;
	var after;
	if (theImg == element+".png") {
		document.getElementById(element).src="images/facilities/"+element+"_hover.png";
		newdigit="1";
	}else{
		document.getElementById(element).src="images/facilities/"+element+".png";
		newdigit="0";
	}
	if(position==0){
		after=values.substring(1,values.length);
		finalvalue=newdigit+after;
	}else{
		before=values.substring(0,position);
		after=values.substring(position+1,values.length);
		finalvalue=before+newdigit+after;
	}
	document.getElementById("facilitiesvalues").value = finalvalue;
}
<!----Javascript for clearing selected facility icons---!>
function clearFacilities(){
	var facilities = new Array("airport","baby","barr","beach","car_parking","alarm","Elevator","entertainment","gym","safe","internet","iron","laundry","mailbox","exchange",
							   "satellite","smoking","spa","conference","pool","heating","ac","pets");
	var i;
	for(i in facilities){
		document.getElementById(facilities[i]).src="images/facilities/"+facilities[i]+".png";
	}
	document.getElementById("facilitiesvalues").value = "00000000000000000000000";
}
function addField(){
	var doc = document;
	var r = doc.getElementById('roomsleft');
	r.innerHTML+='<hr>\
				<table>\
				<tr>\
				<td><?php echo get_word($lang,"Room Type");?></td>\
				<td><?php echo get_word($lang,"No of Rooms");?></td>\
				</tr>\
				<tr>\
				<td><input id="roomtype'+roomnum+'" type="text" name="roomtype'+roomnum+'" size="30"></td>\
				<td><input id="roomnum'+roomnum+'" type="text" name="roomnum'+roomnum+'" size="10"></td>\
				</tr>\
				</table>\
				<table>\
				<tr>\
				<td><?php echo get_word($lang,"Please write the rooms description below");?></td>\
				</tr>\
				<tr>\
				<td><textarea name="room_description'+roomnum+'" id="room_description'+roomnum+'" cols="50" rows="5"></textarea></td>\
				<td>\
				<table>\
				<tr>\
				<td width="120">\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="minibar">Mini bar\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="bathtub">Bath Tub\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="inroomsafe">In room safe\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="tv">Tv/Pay-tv\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="balcony">Balcony\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="radio">Radio\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="phone">Phone\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="ac">A/C\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="bathacc">Bath accessories\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="wc">WC\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="hairdryer">Hairdryer\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="desk">Desk\
				</td>\
				</tr>\
				<tr>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="towels">Towels\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="view">View\
				</td>\
				<td>\
				<input type="checkbox" id="things'+roomnum+'[]" name="things'+roomnum+'[]" value="heating">Heating\
				</td>\
				</tr>\
				</table>\
				</td>\
				</tr>\
				</table>\
				Pictures<BR>\
				<input type="file" name="roompicture'+roomnum+'1" id="roompicture'+roomnum+'1"><BR>\
				<input type="file" name="roompicture'+roomnum+'2" id="roompicture'+roomnum+'2">';
	roomnum++;
}
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="js/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
<?php
	$query="SELECT * FROM roomtypes WHERE hotel_id=".$_GET['hid'];
	$roomsresult=mysql_query($query);
	$roomsnum=mysql_num_rows($roomsresult)-1;
?>
var roomnum=<?php echo $roomsnum;?>;
</script>

</head>

<body>
<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="?hid=<?php echo $_GET['hid'];?>&lang=<?php echo $lang;?>" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return checkFields();">
	<h2><?php echo get_word($lang,"Edit Hotel");?></h2>
	<table border="0" cellspacing="5" cellpadding="0">
		<tr>
			<td width="129"><?php echo get_word($lang,"Country");?></td>
			<td width="153">
				<select name="country" id="country">
					<?php
						$query="SELECT * FROM hotel JOIN cities ON hotel.city_id=cities.id JOIN countries ON hotel.country_id=countries.id WHERE hotel_id=".$_GET['hid'];
						$result=mysql_query($query);
						$info=mysql_fetch_array($result);
						$query="SELECT * FROM countries";
						$result=mysql_query($query);
						echo mysql_num_rows($result);
						while(($row=mysql_fetch_array($result))!=NULL){
							if($row['country']==$info['country'])
								echo "<option value=\"".$row['country']."\" selected>".$row['country']."</option>";
							else
								echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
						}
					?>
				</select>
			</td>
		</tr>
		<tr>
		<?php 
			//GET INFORMATION FOR SELECTED HOTEL
			
		?>
			<td><?php echo get_word($lang,"City");?></td>
			<td>
				<input name="city" type="text" id="city" maxlength="40" value="<?php echo $info['city']?>"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Name");?></td>
			<td>
				<input name="name" type="text" id="name" maxlength="40" value="<?php echo $info['name']?>"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Address");?></td>
			<td>
				<input name="address" type="text" id="address" maxlength="100" value="<?php echo $info['hotel_address']?>"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Phone 1");?></td>
			<td>
				<input name="phone1" type="text" id="phone1" maxlength="20" value="<?php echo $info['phone1']?>"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Phone 2");?></td>
			<td>
				<input name="phone2" type="text" id="phone2" maxlength="20" value="<?php echo $info['phone2']?>"/>
			</td>
		</tr>
		<tr>
			<td>Fax</td>
			<td>
				<input type="text" name="fax" id="fax" value="<?php echo $info['phone3']?>"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Mobile Phone");?></td>
			<td>
				<input name="mobile" type="text" id="mobile" maxlength="20" value="<?php echo $info['phone4']?>"/>
			</td>
		</tr>
		<tr>
			<td>Email</td>
			<td>
				<input name="email" type="text" id="email" maxlength="100" value="<?php echo $info['contact_email']?>"/>
			</td>
		</tr>
	</table><BR /><BR />
	<div class="errors">
		<?php echo $error; ?>
	</div>
	<div class="messages">
		<?php echo $message; ?>
	</div>
	<div class="tabber">
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Description");?></h2>
			<?php echo get_word($lang,"Please write the hotel description below");?><BR>
			<textarea id="hotel_description" name="hotel_description" cols="50" rows="5"><?php echo $info['hotel_description']?></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Rooms");?></h2>
			<div id="roomsleft">
			<?php
				$i=0;
				$roomsnumtoshow=array();
				while(($row=mysql_fetch_array($roomsresult))!=NULL){
				
				echo "<table>
				<tr>
				<td>".get_word($lang,"Room Type")."</td>
				<td>".get_word($lang,"No of Rooms")."</td>
				</tr>
				<tr>
				<td><input id=\"roomtype".$i."\" type=\"text\" name=\"roomtype".$i."\" value=\"".$row['room_type']."\" size=\"30\"></td>
				<td><input id=\"roomnum".$i."\" type=\"text\" name=\"roomnum".$i."\" value=\"".$row['rooms_number']."\" size=\"10\"></td>
				</tr>
				</table>
				<table>
				<tr>
				<td>".get_word($lang,"Please write the rooms description below")."</td>
				</tr>
				<tr>
				<td><textarea name=\"room_description".$i."\" id=\"room_description".$i."\" cols=\"50\" rows=\"5\">".$row['description']."</textarea></td>
				<td>
				<table>
				<tr>";
				$facvalues=array($row['minibar'],$row['bathtub'],$row['safe'],$row['tv'],$row['balcony'],$row['radio'],$row['phone'],$row['ac'],
				$row['bathacc'],$row['wc'],$row['dryer'],$row['desk'],$row['towels'],$row['view'],$row['heating']);
				foreach ($facvalues as $key=>$value){
					if($value==0)
						$facvalues[$key]="";
					else
						$facvalues[$key]="checked";
				}
				echo "<td width=\"120\">
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"minibar\" ".$facvalues[0].">Mini bar
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"bathtub\" ".$facvalues[1].">Bath Tub
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"inroomsafe\" ".$facvalues[2].">In room safe
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"tv\" ".$facvalues[3].">Tv/Pay-tv
				</td>
				</tr>
				<tr>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"balcony\" ".$facvalues[4].">Balcony
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"radio\" ".$facvalues[5].">Radio
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"phone\" ".$facvalues[6].">Phone
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"ac\" ".$facvalues[7].">A/C
				</td>
				</tr>
				<tr>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"bathacc\" ".$facvalues[8].">Bath accessories
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"wc\" ".$facvalues[9].">WC
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"hairdryer\" ".$facvalues[10].">Hairdryer
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"desk\" ".$facvalues[11].">Desk
				</td>
				</tr>
				<tr>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"towels\" ".$facvalues[12].">Towels
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"view\" ".$facvalues[13].">View
				</td>
				<td>
				<input type=\"checkbox\" id=\"things".$i."[]\" name=\"things".$i."[]\" value=\"heating\" ".$facvalues[14].">Heating
				</td>
				</tr>
				</table>
				</td>
				</tr>
				</table>
				Pictures<BR>
				<table>
				<tr>
				<td>
				<CENTER><img src=\"images/hotels/".$row['picture1']."\" height=\"150\" width=\"150\"></CENTER>
				</td>
				<td>
				<CENTER><img src=\"images/hotels/".$row['picture2']."\" height=\"150\" width=\"150\"></CENTER>
				</td>
				</tr>
				<tr>
				<td>
				<input type=\"file\" name=\"roompicture".$i."1\" id=\"roompicture".$i."1\">
				</td>
				<td>
				<input type=\"file\" name=\"roompicture".$i."2\" id=\"roompicture".$i."2\">
				</td>
				</tr>
				</table><HR>";
				$i++;
				}
			?>
			</div>
			<span id="addmore" onclick="addField();"><?php echo get_word($lang,"Add More");?></span>
			<div style="clear:both"></div>
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Area");?></h2>
			<?php echo get_word($lang,"Please write the area description below");?><BR>
			<textarea name="area_description" id="area_description" cols="50" rows="5" ><?php echo $info['area_description']?></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"How to arrive");?></h2>
			<?php echo get_word($lang,"Please write the instructions for how to arrive below");?><BR>
			<textarea name="travel_description" id="travel_description" cols="50" rows="5"><?php echo $info['travel_description']?></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Food");?></h2>
			<?php echo get_word($lang,"Please write the meals description below");?><BR>
			<textarea name="food_description" id="food_description" cols="50" rows="5"><?php echo $info['food_description']?></textarea><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Pictures");?></h2>
			<?php echo get_word($lang,"Please select up to 5 hotel pictures to upload below")."<BR>(JPG, GIF, PNG, max 2MB)";?><BR>
			<table border="0" cellspacing="2" cellpadding="1">
				<tr>
					<td style="width:100px;">
						<CENTER><img src="images/hotels/<?php echo $info['photo1']?>" height="150" width="150"></CENTER>
					</td>
					<td style="width:100px;">
						<CENTER><img src="images/hotels/<?php echo $info['photo2']?>" height="150" width="150"></CENTER>
					</td>
					<td style="width:100px;">
						<CENTER><img src="images/hotels/<?php echo $info['photo3']?>" height="150" width="150"></CENTER>
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture2" id="picture2" />
					</td>
					<td>
						<input type="file" name="picture1" id="picture1" />
					</td>
					<td>
						<input type="file" name="picture3" id="picture3" />
					</td>
					
				</tr>
				<tr>
					<td style="width:100px;">
						<CENTER><img src="images/hotels/<?php echo $info['photo4']?>" height="150" width="150"></CENTER>
					</td>
					<td style="width:100px;">
						<CENTER><img src="images/hotels/<?php echo $info['photo5']?>" height="150" width="150"></CENTER>
					</td>
				</tr>
				<tr>
					<td>
						<input type="file" name="picture4" id="picture4" />
					</td>
					<td>
						<input type="file" name="picture5" id="picture5" />
					</td>
				</tr>
				<tr>
					
				</tr>
			</table>
		</div>
		<div class="tabbertab facilities">
			<h2><?php echo get_word($lang,"Facilities");?></h2>
			<?php echo get_word($lang,"Please select the available facilities below.");?><BR>
			<?php echo get_word($lang,"Selected facilities are highlighted with green color.");?><BR>
			<?php
				$query="SELECT * FROM hotel_facilities WHERE hotel_id=".$_GET['hid'];
				$result=mysql_query($query);
				$facilities=array();
				$valuesfield="00000000000000000000000";
				$row=mysql_fetch_array($result,MYSQL_NUM);
				foreach($row as $value=>$key){
					if($value!=0){
						if($key==1){
							$valuesfield[$value-1]=$key;
							$facilities[]="_hover";
						}
						else{
							$valuesfield[$value-1]=$key;
							$facilities[]="";
						}
					}
				}
			?>
			<table border="0">
				<tr class="line1">
					<td>
						<div class="hoverbox">
							<img id="airport" src="images/facilities/airport<?php echo $facilities[0]; ?>.png" alt="Near Airport" onclick="changeImage('airport',0);"/>
							<span><?php echo get_word($lang,"Near Airport");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="baby" src="images/facilities/baby<?php echo $facilities[1]; ?>.png" alt="Baby Sitting" onclick="changeImage('baby',1);"/>
							<span><?php echo get_word($lang,"Baby Sitting");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="barr" src="images/facilities/barr<?php echo $facilities[2]; ?>.png" alt="Bar Available" onclick="changeImage('barr',2);"/>
							<span>Bar</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="beach" src="images/facilities/beach<?php echo $facilities[3]; ?>.png" alt="Near Beach" onclick="changeImage('beach',3);"/>
							<span><?php echo get_word($lang,"Near Beach");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="car_parking" src="images/facilities/car_parking<?php echo $facilities[4]; ?>.png" alt="Parking Available" onclick="changeImage('car_parking',4);"/>
							<span>Parking</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="alarm" src="images/facilities/alarm<?php echo $facilities[5]; ?>.png" alt="Alarm Service" onclick="changeImage('alarm',5);"/>
							<span><?php echo get_word($lang,"Alarm Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="Elevator" src="images/facilities/Elevator<?php echo $facilities[7]; ?>.png" alt="Elevator Available" onclick="changeImage('Elevator',7);"/>
							<span><?php echo get_word($lang,"Elevator Available");?></span>
						</div>
					</td>
				</tr>
				<tr class="line2">
					<td>
						<div class="hoverbox">
							<img id="entertainment" src="images/facilities/entertainment<?php echo $facilities[8]; ?>.png" alt="Entertainment Hall" onclick="changeImage('entertainment',8);"/>
							<span><?php echo get_word($lang,"Entertainment Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="gym" src="images/facilities/gym<?php echo $facilities[9]; ?>.png" alt="Gym facilities" onclick="changeImage('gym',9);"/>
							<span><?php echo get_word($lang,"Gym Facilities");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="safe" src="images/facilities/safe<?php echo $facilities[10]; ?>.png" alt="Safe" onclick="changeImage('safe',10);"/>
							<span><?php echo get_word($lang,"In room Safe");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="internet" src="images/facilities/internet<?php echo $facilities[11]; ?>.png" alt="Internet" onclick="changeImage('internet',11);"/>
							<span>Internet</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="iron" src="images/facilities/iron<?php echo $facilities[12]; ?>.png" alt="Iron" onclick="changeImage('iron',12);"/>
							<span><?php echo get_word($lang,"In room Iron");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="laundry" src="images/facilities/laundry<?php echo $facilities[13]; ?>.png" alt="Laundry Service" onclick="changeImage('laundry',13);"/>
							<span><?php echo get_word($lang,"Laundry Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="mailbox" src="images/facilities/mailbox<?php echo $facilities[14]; ?>.png" alt="mailbox" onclick="changeImage('mailbox',14);"/>
							<span><?php echo get_word($lang,"Mailbox");?></span>
						</div>
					</td>
				</tr>
				<tr class="line3">
					<td>
						<div class="hoverbox">
							<img id="exchange" src="images/facilities/exchange<?php echo $facilities[15]; ?>.png" alt="Money Exchange" onclick="changeImage('exchange',15);"/>
							<span><?php echo get_word($lang,"Money Exchange");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="satellite" src="images/facilities/satellite<?php echo $facilities[16]; ?>.png" alt="Satellite tv" onclick="changeImage('satellite',16);"/>
							<span><?php echo get_word($lang,"Satellite Tv");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="spa" src="images/facilities/spa<?php echo $facilities[18]; ?>.png" alt="Spa" onclick="changeImage('spa',18);"/>
							<span>Spa</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="conference" src="images/facilities/conference<?php echo $facilities[6]; ?>.png" alt="Conference Hall" onclick="changeImage('conference',6);"/>
							<span><?php echo get_word($lang,"Conference Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="pool" src="images/facilities/pool<?php echo $facilities[19]; ?>.png" alt="Swimming Pool" onclick="changeImage('pool',19);"/>
							<span><?php echo get_word($lang,"Swimming Pool");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="heating" src="images/facilities/heating<?php echo $facilities[20]; ?>.png" alt="Heating" onclick="changeImage('heating',20);"/>
							<span><?php echo get_word($lang,"Heating");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="ac" src="images/facilities/ac<?php echo $facilities[21]; ?>.png" alt="Air Conditioning" onclick="changeImage('ac',21);"/>
							<span><?php echo get_word($lang,"Air Conditioning");?></span>
						</div>
					</td>
				</tr>
			</table>
			<div class="smokepets">
				<table border=0>
					<tr>
						<td>
							<div class="hoverbox">
								<img id="pets" src="images/facilities/pets<?php echo $facilities[22]; ?>.png" alt="Pets" onclick="changeImage('pets',22);"/>
								<span><?php echo get_word($lang,"Pets Allowed");?></span>
							</div>
						</td>
						<td>
							<div class="hoverbox">
								<img id="smoking" src="images/facilities/smoking<?php echo $facilities[17]; ?>.png" alt="Smoking" onclick="changeImage('smoking',17);"/>
								<span><?php echo get_word($lang,"Smoking Allowed");?></span>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<div id="clearfacilities" onclick="clearFacilities();"><?php echo get_word($lang,"Clear Selected Facilities");?></div>
			<input type="hidden" name="facilitiesvalues" id="facilitiesvalues" value="<?php echo $valuesfield;?>">
		</div><BR><BR>
		<CENTER><input type="submit" name="submit" id="submit" value="<?php echo get_word($lang,"Save");?>" onClick=""><input type="button" name="cancel" id="cancel" value="<?php echo get_word($lang,"Cancel");?>" onClick="window.location='index.php'"></CENTER>
	</div>
	</form>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
