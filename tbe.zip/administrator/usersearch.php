<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	$message="";
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language	
	//remove a hotel if the delete variable is set to a hotel id
	if(isset($_GET['delete'])){
		$query="DELETE FROM users WHERE username='".$_GET['delete']."'";
		mysql_query($query);
		$message=get_word($lang,"User Removed Successfully");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">
function showResult(){
	var name=document.getElementById('name').value;
	var surname=document.getElementById('surname').value;
	var username=document.getElementById('username').value;
	var params = "name="+name+"&surname="+surname+"&username="+username+"&lang=<?php echo $lang;?>";
	http=new XMLHttpRequest();
	
	http.open("POST","liveusersearch.php",true);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	http.send(params);
	http.onreadystatechange = function() {//Call a function when the state changes.
		if(http.readyState == 4 && http.status == 200){
			document.getElementById("livesearch").innerHTML=http.responseText;
		}
	}

	
}
function removeuser(username){
	var answer = confirm ("<?php echo get_word($lang,'Are you sure you want to remove this user?');?>");
	if(answer)
		window.location="?delete="+username;		
}
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="js/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
</head>

<body>

<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="?lang=<?php echo $lang;?>" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return false;">
	<h2><?php echo get_word($lang,"Search Users");?></h2>
	<h4><?php echo get_word($lang,"Use the username(or part of it), name or surname to get detailed information or edit a user.");?></h4>
	<table border="0" cellspacing="5" cellpadding="0">
		<tr>
			<td width="129"><?php echo get_word($lang,"Name");?></td>
			<td width="153">
				<input name="name" type="text" id="name" maxlength="100" autocomplete="off" onkeyup="showResult();"/>
				
			</td>
        </tr>
        <tr>
        	<td width="129"><?php echo get_word($lang,"Surname");?></td>
            <td width="153">
				<input name="surname" type="text" id="surname" maxlength="100" autocomplete="off" onkeyup="showResult();"/>
				
			</td>
        </tr>
        <tr>
            <td width="129"><?php echo get_word($lang,"Username");?></td>
			<td width="153">
				<input name="username" type="text" id="username" maxlength="100" autocomplete="off" onkeyup="showResult();"/>
				
			</td>
		</tr>
	</table><BR /><BR />
		<div class="messages">
			<?php echo $message; ?>
		</div>
		<CENTER><input type="submit" name="submit" id="submit" onclick="showResult();" value="<?php echo get_word($lang,"Search");?>" onClick=""></CENTER>
	</form>
	<div id="livesearch" name="livesearch"></div>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
