<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<style>
	#title a,#title a:hover,#title a:visited{
		color:#FFF;
	}
	body{
		font-family:Verdana;	
		font-size:11px;
	}
	#box{
		position:absolute;
		top:50%;
		margin-top:-250px;
		left:50%;
		margin-left:-350px;
		width:700px;
		height:500px;
		border:1px solid #DEDEDE;
	}
	#title{
		text-align:center;	
		border-bottom:1px solid #dedede;
		background:#5970B2;
		color:#FFF;
	}
	h1,h2{
		padding:0;
		margin:0;
	}
	td{
		text-align:center;	
	}
	#hotels,#users{
		padding:5px 10px;	
		border-bottom:2px dashed #dedede;
	}
</style>
</head>
<body>
	<div id="box">
    	<div id="title">
        	<h1><?php echo $site_title;?></h1>
			<div style="position:absolute;top:3px;right:5px;" id="langselect">
				<?php include "includes/languagebar.php";?>
			</div>
			<div style="position:absolute;top:5px;left:5px;" id="Logout">
				<a href="login.php"><?php echo get_word($lang,"Logout");?></a>
			</div>
        </div>
        <div id="hotels">
        	<h2><?php echo get_word($lang,"Hotels");?></h2>
            <table width="100%" cellpadding=0 cellspacing=0>
            	<tr>
                	<td>
                    	<a href="addhotel.php"><img src="images/icons/addicon.png" align="top" border=0/></a>
                    </td>
                    <td>
                    	<a href="search.php"><img src="images/icons/searchicon.png" align="top" border=0/></a>
                    </td>
                    <td>
                    	<a href="search.php"><img src="images/icons/editicon.png" align="top" border=0/></a>
                    </td>
                    <td>
                    	<a href="search.php"><img src="images/icons/removeicon.png" align="top" border=0/></a>
                    </td>
                </tr>
            	<tr>
                	<td>
                    	<a href="addhotel.php"><?php echo get_word($lang,"Add a Hotel");?></a>
                    </td>
                    <td>
                    	<a href="search.php"><?php echo get_word($lang,"Search a Hotel");?></a>
                    </td>
                    <td>
                    	<a href="search.php"><?php echo get_word($lang,"Edit Hotel Information/Prices");?></a>
                    </td>
                    <td>
                    	<a href="search.php"><?php echo get_word($lang,"Remove a Hotel");?></a>
                    </td>
                </tr>
            </table>
        </div>
		<div id="users">
        	<h2><?php echo get_word($lang,"Users");?></h2>
            <table width="100%" cellpadding=0 cellspacing=0>
            	<tr>
                	<td>
                    	<a href="adduser.php"><img src="images/icons/adduser.png" align="top" border=0/></a>
                    </td>
                    <td>
                    	<a href="usersearch.php"><img src="images/icons/edituser.png" align="top" border=0/></a>
                    </td>
                    <td>
                    	<a href="usersearch.php"><img src="images/icons/removeuser.png" align="top" border=0/></a>
                    </td>
                </tr>
            	<tr>
                	<td>
                    	<a href="adduser.php"><?php echo get_word($lang,"Add user");?></a>
                    </td>
                    <td>
                    	<a href="usersearch.php"><?php echo get_word($lang,"Edit User");?></a>
                    </td>
                    <td>
                    	<a href="usersearch.php"><?php echo get_word($lang,"Remove User");?></a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
