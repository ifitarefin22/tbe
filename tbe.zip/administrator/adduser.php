<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header("Location:login.php");
	}
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$error="";
	$message="";
	$warn=0;
	
	//Checks form fields
	if(isset($_POST['submit'])){
		if(!isset($_POST['name'])){
			$error=get_word($lang,"Name field cannot be empty!");
		}else if(!isset($_POST['surname'])){
			$error=get_word($lang,"Surname field cannot be empty!");
		}else if(!isset($_POST['username'])){
			$error=get_word($lang,"Username field canot be empty!");
		}else if((!isset($_POST['password']))&&(!isset($_POST['phone2']))){
			$error=get_word($lang,"Password field cannot be empty!");
		}else if(!isset($_POST['email'])){
			$error=get_word($lang,"A contact email must be inserted!");
		}else if(!isset($_POST['type'])){
			$error=get_word($lang,"You havent chosen the type of the account!");
		}else if(!check_user_email($_POST['username'],$_POST['email'])){
			$error=get_word($lang,"Sorry, the username or email is already in use!");
		}else{
		//---------------------------------ADDING USER---------------------------------------
			$query="INSERT INTO users VALUES ('".$_POST['name']."','".$_POST['surname']."','".$_POST['phone']
					."','".$_POST['country']."','".$_POST['username']."','".$_POST['password']."','".$_POST['email']."','".$_POST['type']."')";
			mysql_query($query);
			
			$message=get_word($lang,"User added succesfully!");
		}
	}
	//------------------End of the user addition
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">

<!----Javascript for checking for empty fields icons---!>
function checkFields(){
	if(document.getElementById("name").value==""){
		alert("<?php echo get_word($lang,"Name field cannot be empty!");?>");
		document.getElementById("name").focus();
		return false;
	}else if(document.getElementById("surname").value==""){
		alert("<?php echo get_word($lang,"Surname field cannot be empty!");?>");
		document.getElementById("surname").focus();
		return false;
	}else if(document.getElementById("username").value==""){
		alert("<?php echo get_word($lang,"Username field cannot be empty!");?>");
		document.getElementById("username").focus();
		return false;
	}else if(document.getElementById("password").value==""){
		alert("<?php echo get_word($lang,"Password field cannot be empty!");?>");
		document.getElementById("password").focus();
		return false;
	}else if(document.getElementById("email").value==""){
		alert("<?php echo get_word($lang,"A contact email must be inserted!");?>");
		document.getElementById("email").focus();
		return false;
	}else if(document.getElementById("type").value==""){
		alert("<?php echo get_word($lang,"You havent chosen the type of the account!");?>");
		return false;
	}else if(document.getElementById("password").value!=document.getElementById("repeat").value){
		alert("<?php echo get_word($lang,"Password and Repeat Password do not match!");?>");
		document.getElementById("password").focus();
		return false;
	}else{
		return true;
	}
}
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="js/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
var roomnum=1;
</script>

</head>

<body>
<div id="maincontent">
	<div id="topmenu">
		<?php include "includes/menu.php";?>
		<div id="langselect">
			<?php include "includes/languagebar.php";?>
		</div>
	</div>
	<form action="adduser.php" method="post" name="form1" id="form1" onsubmit="return checkFields();">
	<h2><?php echo get_word($lang,"Add User");?></h2>
	<table border="0" cellspacing="5" cellpadding="0">
		<tr>
			<td><?php echo get_word($lang,"Name");?></td>
			<td>
				<input name="name" type="text" id="name" maxlength="40"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Surname");?></td>
			<td>
				<input name="surname" type="text" id="surname" maxlength="40"/>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Phone");?></td>
			<td>
				<input name="phone" type="text" id="phone" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td width="129"><?php echo get_word($lang,"Country");?></td>
			<td width="153">
				<select name="country" id="country">
					<?php
						$query="SELECT * FROM countries";
						$result=mysql_query($query);
						echo mysql_num_rows($result);
						while(($row=mysql_fetch_array($result))!=NULL){
							echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
						}
					?>
				</select>
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Username");?></td>
			<td>
				<input name="username" type="text" id="username" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Password");?></td>
			<td>
				<input type="password" name="password" id="password" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Repeat Password");?></td>
			<td>
				<input name="repeat" type="password" id="repeat" maxlength="20" />
			</td>
		</tr>
		<tr>
			<td>Email</td>
			<td>
				<input name="email" type="text" id="email" maxlength="100" />
			</td>
		</tr>
		<tr>
			<td><?php echo get_word($lang,"Type");?></td>
			<td>
				<input name="type" type="radio" id="type" value="user" checked/><?php echo get_word($lang,"User");?>
				<input name="type" type="radio" id="type" value="administrator" /><?php echo get_word($lang,"Administrator");?>
			</td>
		</tr>
	</table><BR /><BR />
	<div class="errors">
		<?php echo $error; ?>
	</div>
	<div class="messages">
		<?php echo $message; ?>
	</div>
	<CENTER><input type="submit" name="submit" id="submit" value="<?php echo get_word($lang,"Save");?>" onClick=""><input type="button" name="cancel" id="cancel" value="<?php echo get_word($lang,"Cancel");?>" onClick="window.location='index.php'"></CENTER>
	</form>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
