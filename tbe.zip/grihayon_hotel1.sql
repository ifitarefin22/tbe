-- MySQL dump 10.19  Distrib 10.3.36-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: grihayon_hotel1
-- ------------------------------------------------------
-- Server version	10.3.36-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `hotel_id` int(20) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `room_type` varchar(40) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `expires` datetime NOT NULL,
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `country_id` int(10) NOT NULL,
  `city` varchar(40) NOT NULL,
  `numhotels` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city` (`city`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `hotel_id` int(20) NOT NULL,
  `comment` varchar(200) NOT NULL,
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country` varchar(64) DEFAULT NULL,
  `flag` text NOT NULL,
  `country_code` char(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_country_name` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=240 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` (`id`, `country`, `flag`, `country_code`) VALUES (1,'Afghanistan','Afghanistan-Flag.png','AF'),(2,'Albania','Albania-Flag.png','AL'),(3,'Algeria','Algeria-Flag.png','DZ'),(4,'American Samoa','American-Samoa-Flag.png','AS'),(5,'Andorra','Andorra-Flag.png','AD'),(6,'Angola','Angola-Flag.png','AO'),(7,'Anguilla','Anguilla-Flag.png','AI'),(8,'Antarctica','Antarctica-Flag.png','AQ'),(9,'Antigua and Barbuda','Antigua-and-Barbuda-Flag.png','AG'),(10,'Argentina','Argentina-Flag.png','AR'),(11,'Armenia','Armenia-Flag.png','AM'),(12,'Aruba','Aruba-Flag.png','AW'),(13,'Australia','Australia-Flag.png','AU'),(14,'Austria','Austria-Flag.png','AT'),(15,'Azerbaijan','Azerbaijan-Flag.png','AZ'),(16,'Bahamas','Bahamas-Flag.png','BS'),(17,'Bahrain','Bahrain-Flag.png','BH'),(18,'Bangladesh','Bangladesh-Flag.png','BD'),(19,'Barbados','Barbados-Flag.png','BB'),(20,'Belarus','Belarus-Flag.png','BY'),(21,'Belgium','Belgium-Flag.png','BE'),(22,'Belize','Belize-Flag.png','BZ'),(23,'Benin','Benin-Flag.png','BJ'),(24,'Bermuda','Bermuda-Flag.png','BM'),(25,'Bhutan','Bhutan-Flag.png','BT'),(26,'Bolivia','Bolivia-Flag.png','BO'),(27,'Bosnia and Herzegowina','Bosnia-and-Herzegovina-Flag.png','BA'),(28,'Botswana','Botswana-Flag.png','BW'),(29,'Bouvet Island','Bouvet Island.jpg','BV'),(30,'Brazil','Brazil-Flag.png','BR'),(31,'British Indian Ocean Territory','british india territory.jpg','IO'),(32,'Brunei Darussalam','Brunei-Flag.png','BN'),(33,'Bulgaria','Bulgaria-Flag.png','BG'),(34,'Burkina Faso','Burkina-Faso-Flag.png','BF'),(35,'Burundi','Burundi-Flag.png','BI'),(36,'Cambodia','Cambodia-Flag.png','KH'),(37,'Cameroon','Cameroon-Flag.png','CM'),(38,'Canada','Canada-Flag.png','CA'),(39,'Cape Verde','Cape-Verde-Flag.png','CV'),(40,'Cayman Islands','Cayman-Islands-Flag.png','KY'),(41,'Central African Republic','Central African Republic.jpg','CF'),(42,'Chad','Chad-Flag.png','TD'),(43,'Chile','Chile-Flag.png','CL'),(44,'China','China-Flag.png','CN'),(45,'Christmas Island','ci-flag.jpg','CX'),(46,'Cocos (Keeling) Islands','Cook-Islands-Flag.png','CC'),(47,'Colombia','Colombia-Flag.png','CO'),(48,'Comoros','Comoros-Flag.png','KM'),(49,'Congo','Congo-Brazzaville-Flag.png','CG'),(50,'Cook Islands','Cook-Islands-Flag.png','CK'),(51,'Costa Rica','Costa-Rica-Flag.png','CR'),(52,'Cote D\'Ivoire','Cote-DIvoire-Flag.png','CI'),(53,'Croatia','Croatia-Flag.png','HR'),(54,'Cuba','Cuba-Flag.png','CU'),(55,'Cyprus','Cyprus-Flag.png','CY'),(56,'Czech Republic','Czech-Republic-Flag.png','CZ'),(57,'Denmark','Denmark-Flag.png','DK'),(58,'Djibouti','Djibouti-Flag.png','DJ'),(59,'Dominica','Dominica-Flag.png','DM'),(60,'Dominican Republic','Dominican-Republic-Flag.png','DO'),(61,'East Timor','East-Timor-Flag.png','TP'),(62,'Ecuador','Ecuador-Flag.png','EC'),(63,'Egypt','Egypt-Flag.png','EG'),(64,'El Salvador','El-Salvador-Flag.png','SV'),(65,'Equatorial Guinea','Equatorial-Guinea-Flag.png','GQ'),(66,'Eritrea','Eritrea-Flag.png','ER'),(67,'Estonia','Estonia-Flag.png','EE'),(68,'Ethiopia','Ethiopia-Flag.png','ET'),(69,'Falkland Islands (Malvinas)','fk-t.gif','FK'),(70,'Faroe Islands','Faroes-Flag.png','FO'),(71,'Fiji','Fiji-Flag.png','FJ'),(72,'Finland','Finland-Flag.png','FI'),(73,'France','France-Flag.png','FR'),(74,'France, Metropolitan','france_flag.gif','FX'),(75,'French Guiana','','GF'),(76,'French Polynesia','','PF'),(77,'French Southern Territories','','TF'),(78,'Gabon','Gabon-Flag.png','GA'),(79,'Gambia','Gambia-Flag.png','GM'),(80,'Georgia','Georgia-Flag.png','GE'),(81,'Germany','Germany-Flag.png','DE'),(82,'Ghana','Ghana-Flag.png','GH'),(83,'Gibraltar','Gibraltar-Flag.png','GI'),(84,'Greece','Greece-Flag.png','GR'),(85,'Greenland','Greenland-Flag_sm.jpg','GL'),(86,'Grenada','Grenada-Flag.png','GD'),(87,'Guadeloupe','Flag_Guadeloupe-_emL3x2.gif','GP'),(88,'Guam','Guam-Flag.png','GU'),(89,'Guatemala','Guatemala-Flag.png','GT'),(90,'Guinea','Guinea-Bissau-Flag.png','GN'),(91,'Guinea-bissau','Guinea-Bissau-Flag.png','GW'),(92,'Guyana','Guyana-Flag.png','GY'),(93,'Haiti','Haiti-Flag.png','HT'),(94,'Heard and Mc Donald Islands','heard-island-and-mcdonald-islands.gif','HM'),(95,'Honduras','Honduras-Flag.png','HN'),(96,'Hong Kong','Hong-Kong-Flag.png','HK'),(97,'Hungary','Hungary-Flag.png','HU'),(98,'Iceland','Iceland-Flag.png','IS'),(99,'India','India-Flag.png','IN'),(100,'Indonesia','Indonezia-Flag.png','ID'),(101,'Iran (Islamic Republic of)','Iran-Flag.png','IR'),(102,'Iraq','Iraq-Flag.png','IQ'),(103,'Ireland','Ireland-Flag.png','IE'),(104,'Israel','Israel-Flag.png','IL'),(105,'Italy','Italy-Flag.png','IT'),(106,'Jamaica','Jamaica-Flag.png','JM'),(107,'Japan','Japan-Flag.png','JP'),(108,'Jordan','Jordan-Flag.png','JO'),(109,'Kazakhstan','Kazakhstan-Flag.png','KZ'),(110,'Kenya','Kenya-Flag.png','KE'),(111,'Kiribati','Kiribati-Flag.png','KI'),(112,'Korea, Democratic People\'s Republic of','KP.gif','KP'),(113,'Korea, Republic of','South-Korea-Flag.png','KR'),(114,'Kuwait','Kuwait-Flag.png','KW'),(115,'Kyrgyzstan','Kyrgyzstan-Flag.png','KG'),(116,'Lao People\'s Democratic Republic','Laos-Flag.png','LA'),(117,'Latvia','Latvia-Flag.png','LV'),(118,'Lebanon','Lebanon-Flag.png','LB'),(119,'Lesotho','Lesotho-Flag.png','LS'),(120,'Liberia','Liberia-Flag.png','LR'),(121,'Libyan Arab Jamahiriya','Libya-Flag.png','LY'),(122,'Liechtenstein','Liechtenshein-Flag.png','LI'),(123,'Lithuania','Lithuania-Flag.png','LT'),(124,'Luxembourg','Luxembourg-Flag.png','LU'),(125,'Macau','Macau-Flag.png','MO'),(126,'Macedonia, The Former Yugoslav Republic of','Macedonia-Flag.png','MK'),(127,'Madagascar','Madagascar-Flag.png','MG'),(128,'Malawi','Malawi-Flag.png','MW'),(129,'Malaysia','Malaysia-Flag.png','MY'),(130,'Maldives','Maldives-Flag.png','MV'),(131,'Mali','Mali-Flag.png','ML'),(132,'Malta','Malta-Flag.png','MT'),(133,'Marshall Islands','Marshall-Islands-Flag.png','MH'),(134,'Martinique','martinique.png','MQ'),(135,'Mauritania','mauritania-flag.jpg','MR'),(136,'Mauritius','Mauritius-Flag.png','MU'),(137,'Mayotte','60px-Mayotte_flag.gif','YT'),(138,'Mexico','Mexico-Flag.png','MX'),(139,'Micronesia, Federated States of','Micronesia-Flag.png','FM'),(140,'Moldova, Republic of','Moldova-Flag.png','MD'),(141,'Monaco','Monaco-Flag.png','MC'),(142,'Mongolia','Mongolia-Flag.png','MN'),(143,'Montserrat','Montserrat-Flag.png','MS'),(144,'Morocco','Morocco-Flag.png','MA'),(145,'Mozambique','Mozambique-Flag.png','MZ'),(146,'Myanmar','Myanmar-Flag.png','MM'),(147,'Namibia','Namibia-Flag.png','NA'),(148,'Nauru','Nauru-Flag.png','NR'),(149,'Nepal','Nepal-Flag.png','NP'),(150,'Netherlands','Netherlands-Flag.png','NL'),(151,'Netherlands Antilles','50px-Flag_of_the_Netherlands_Antilles.svg.png','AN'),(152,'New Caledonia','Flag-of-New-Caledonia-frenc.gif','NC'),(153,'New Zealand','New-Zealand-Flag.png','NZ'),(154,'Nicaragua','Nicaragua-Flag.png','NI'),(155,'Niger','Niger-Flag.png','NE'),(156,'Nigeria','Nigeria-Flag.png','NG'),(157,'Niue','NU.gif','NU'),(158,'Norfolk Island','Norfolk_Island_flag.gif','NF'),(159,'Northern Mariana Islands','Northern-Ireland-Flag.png','MP'),(160,'Norway','Norway-Flag.png','NO'),(161,'Oman','Oman-Flag.png','OM'),(162,'Pakistan','Pakistan-Flag.png','PK'),(163,'Palau','Palau-Flag.png','PW'),(164,'Panama','Panama-Flag.png','PA'),(165,'Papua New Guinea','Papua-New-Guinea-Flag.png','PG'),(166,'Paraguay','Paraguay-Flag.png','PY'),(167,'Peru','Peru-Flag.png','PE'),(168,'Philippines','Philippines-Flag.png','PH'),(169,'Pitcairn','Pitcairn_Islands _flag.gif','PN'),(170,'Poland','Poland-Flag.png','PL'),(171,'Portugal','Portugal-Flag.png','PT'),(172,'Puerto Rico','Puerto-Rico-Flag.png','PR'),(173,'Qatar','Qatar-Flag.png','QA'),(174,'Reunion','reunion flag.gif','RE'),(175,'Romania','Romania-Flag.png','RO'),(176,'Russian Federation','Russian-Federation-Flag.png','RU'),(177,'Rwanda','Rwanda-Flag.png','RW'),(178,'Saint Kitts and Nevis','St-Kitts-and-Nevis-Flag.png','KN'),(179,'Saint Lucia','Saint-Lucia-Flag.png','LC'),(180,'Saint Vincent and the Grenadines','SVGR0001.GIF','VC'),(181,'Samoa','Samoa-Flag.png','WS'),(182,'San Marino','San-Marino-Flag.png','SM'),(183,'Sao Tome and Principe','Sao-Tome-and-Principe-Flag.png','ST'),(184,'Saudi Arabia','Saudi-Arabia-Flag.png','SA'),(185,'Senegal','Senegal-Flag.png','SN'),(186,'Seychelles','Seychelles-Flag.png','SC'),(187,'Sierra Leone','Sierra-Leone-Flag.png','SL'),(188,'Singapore','Singapore-Flag.png','SG'),(189,'Slovakia (Slovak Republic)','Slovakia-Flag.png','SK'),(190,'Slovenia','Slovenia-Flag.png','SI'),(191,'Solomon Islands','Solomon-Islands-Flag.png','SB'),(192,'Somalia','Somalia-Flag.png','SO'),(193,'South Africa','South-Africa-Flag.png','ZA'),(194,'South Georgia and the South Sandwich Islands','SGSS0001.GIF','GS'),(195,'Spain','Spain-Flag.png','ES'),(196,'Sri Lanka','Sri-Lanka-Flag.png','LK'),(197,'St. Helena','STHC0001.GIF','SH'),(198,'St. Pierre and Miquelon','STPM0001.GIF','PM'),(199,'Sudan','Sudan-Flag.png','SD'),(200,'Suriname','Suriname-Flag.png','SR'),(201,'Svalbard and Jan Mayen Islands','flag_of_Svalbard-and-Jan-Mayen-Islands.gif','SJ'),(202,'Swaziland','Swaziland-Flag.png','SZ'),(203,'Sweden','Sweden-Flag.png','SE'),(204,'Switzerland','Switzerland-Flag.png','CH'),(205,'Syrian Arab Republic','Syria-Flag.png','SY'),(206,'Taiwan','Taiwan-Flag.png','TW'),(207,'Tajikistan','Tajikistan-Flag.png','TJ'),(208,'Tanzania, United Republic of','Tanzania-Flag.png','TZ'),(209,'Thailand','Thailand-Flag.png','TH'),(210,'Togo','Togo-Flag.png','TG'),(211,'Tokelau','Blacki_Tokelau.jpg','TK'),(212,'Tonga','Tonga-Flag.png','TO'),(213,'Trinidad and Tobago','Trinidad-and-Tobago-Flag.png','TT'),(214,'Tunisia','Tunisia-Flag.png','TN'),(215,'Turkey','Turkey-Flag.png','TR'),(216,'Turkmenistan','Turkmenistan-Flag.png','TM'),(217,'Turks and Caicos Islands','Turks-and-Caicos-Islands-Flag.png','TC'),(218,'Tuvalu','Tuvalu-Flag.png','TV'),(219,'Uganda','Uganda-Flag.png','UG'),(220,'Ukraine','Ukraine-Flag.png','UA'),(221,'United Arab Emirates','United-Arab-Emirates-Flag.png','AE'),(222,'United Kingdom','United-Kingdom-Flag.png','GB'),(223,'United States','United-States-of-America-Flag.png','US'),(224,'United States Minor Outlying Islands','United-Kingdom-Flag.png','UM'),(225,'Uruguay','Uruguay-Flag.png','UY'),(226,'Uzbekistan','Uzbekistan-Flag.png','UZ'),(227,'Vanuatu','Vanutau-Flag.png','VU'),(228,'Vatican City State (Holy See)','Vatican-City-Flag.png','VA'),(229,'Venezuela','Venezuela-Flag.png','VE'),(230,'Viet Nam','Viet-Nam-Flag.png','VN'),(231,'Virgin Islands (British)','Virgin-Islands-British-Flag.png','VG'),(232,'Virgin Islands (U.S.)','Virgin-Islands-US-Flag.png','VI'),(233,'Wallis and Futuna Islands','Wales-Flag.png','WF'),(234,'Western Sahara','Western-Sahara-Flag.png','EH'),(235,'Yemen','Yemen-Flag.png','YE'),(236,'Yugoslavia','215.gif','YU'),(237,'Zaire','zaire.jpg','ZR'),(238,'Zambia','Zambia-Flag.png','ZM'),(239,'Zimbabwe','Zimbabwe-Flag.png','ZW');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel` (
  `hotel_id` int(20) NOT NULL AUTO_INCREMENT,
  `city_id` int(20) NOT NULL,
  `country_id` int(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `photo1` varchar(150) NOT NULL,
  `photo2` varchar(150) NOT NULL,
  `photo3` varchar(150) NOT NULL,
  `photo4` varchar(150) NOT NULL,
  `photo5` varchar(150) NOT NULL,
  `hotel_address` varchar(100) NOT NULL,
  `phone1` varchar(20) NOT NULL,
  `phone2` varchar(20) DEFAULT NULL,
  `phone3` varchar(20) DEFAULT NULL,
  `phone4` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) NOT NULL,
  `room_description` varchar(1500) DEFAULT NULL,
  `area_description` varchar(1500) DEFAULT NULL,
  `travel_description` varchar(1500) DEFAULT NULL,
  `food_description` varchar(1500) DEFAULT NULL,
  `rates_added` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`hotel_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_facilities`
--

DROP TABLE IF EXISTS `hotel_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel_facilities` (
  `hotel_id` int(20) NOT NULL,
  `airport` int(1) NOT NULL DEFAULT 0,
  `babysit` int(1) NOT NULL DEFAULT 0,
  `bar` int(1) NOT NULL DEFAULT 0,
  `nearbeach` int(1) NOT NULL DEFAULT 0,
  `parking` int(1) NOT NULL DEFAULT 0,
  `alarm` int(1) NOT NULL DEFAULT 0,
  `conference` int(1) NOT NULL DEFAULT 0,
  `elevator` int(1) NOT NULL DEFAULT 0,
  `entertainment` int(1) NOT NULL DEFAULT 0,
  `gym` int(1) NOT NULL DEFAULT 0,
  `safe` int(1) NOT NULL DEFAULT 0,
  `internet` int(1) NOT NULL DEFAULT 0,
  `iron` int(1) NOT NULL DEFAULT 0,
  `laundry` int(1) NOT NULL DEFAULT 0,
  `mailbox` int(1) NOT NULL DEFAULT 0,
  `moneyexchange` int(1) NOT NULL DEFAULT 0,
  `satelite` int(1) NOT NULL DEFAULT 0,
  `smoking` int(1) NOT NULL DEFAULT 0,
  `spa` int(1) NOT NULL DEFAULT 0,
  `pool` int(1) NOT NULL DEFAULT 0,
  `heating` int(1) NOT NULL DEFAULT 0,
  `ac` int(1) NOT NULL DEFAULT 0,
  `pets` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`hotel_id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_facilities`
--

LOCK TABLES `hotel_facilities` WRITE;
/*!40000 ALTER TABLE `hotel_facilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language` (
  `lang_id` int(20) NOT NULL,
  `word` text NOT NULL,
  `translation` text NOT NULL,
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` (`lang_id`, `word`, `translation`) VALUES (2,'Add a Hotel','Προσθήκη Ξενοδοχείου'),(2,'City','Πόλη'),(2,'Name','Όνομα'),(2,'Address','Διεύθυνση'),(2,'Phone 1','Τηλέφωνο 1'),(2,'Phone 2','Τηλέφωνο 2'),(2,'Description','Περιγραφή'),(2,'Mobile Phone','Κινητό Τηλέφωνο'),(2,'Please write the hotel description below','Παρακαλώ εισάγετε την περιγραφή του ξενοδοχείου παρακάτω'),(2,'Country','Χώρα'),(2,'Rooms','Δωμάτια'),(2,'Please write the rooms description below','Παρακαλώ εισάγετε την περιγραφή των δωματιών παρακάτω'),(2,'Room Type','Είδος Δωματίου'),(2,'No of Rooms','Αρ. Δωματίων'),(2,'Add More','Προσθήκη Περισσότερων'),(2,'Area','Περιοχή'),(2,'Please write the area description below','Παρακαλώ εισάγετε περιγραφή της περιοχής παρακάτω'),(2,'How to arrive','Πώς να φτάσετε'),(2,'Please write the instructions for how to arrive below','Παρακαλώ εισάγετε οδηγίες για τον τρόπο άφιξης παρακάτω'),(2,'Food','Φαγητό'),(2,'Please write the meals description below','Παρακαλώ εισάγετε πληροφορίες για τα γεύματα παρακάτω'),(2,'Pictures','Φωτογραφίες'),(2,'Please select up to 5 hotel pictures to upload below','Παρακαλώ επιλέξτε μέχρι 5 φωτογραφίες του ξενοδοχείου παρακάτω'),(2,'Facilities','Παροχές'),(2,'Please select the available facilities below.','Παρακαλώ επιλέξτε τις διαθέσιμες παροχές παρακάτω.'),(2,'Selected facilities are highlighted with green color.','Οι επιλεγμένες παροχές επισημαίνονται με πράσινο χρώμα.'),(2,'Near Airport','Κοντά σε αεροδρόμιο'),(2,'Baby Sitting','Φύλαξη Παιδιών'),(2,'Near Beach','Κοντά σε Παραλία'),(2,'Alarm Service','Υπηρεσία Αφύπνισης'),(2,'Elevator Available','Ασανσέρ Διαθέσιμο'),(2,'Entertainment Hall','Αίθουσα Διασκέδασης'),(2,'Gym Facilities','Γυμναστήριο'),(2,'In room Safe','Χρηματοκιβώτιο'),(2,'In room Iron','Σίδερο'),(2,'Laundry Service','Πλύσιμο Ρούχων'),(2,'Mailbox','Ταχυδρομικό Κουτί'),(2,'Money Exchange','Ανταλλακτήριο Συναλλάγματος'),(2,'Satellite Tv','Δορυφορική Τηλεόραση'),(2,'Smoking Allowed','Επιτρέπεται το κάπνισμα'),(2,'Conference Hall','Αίθουσα Συνεδριάσεων'),(2,'Swimming Pool','Πισίνα'),(2,'Heating','Θέρμανση'),(2,'Air Conditioning','Air Condition'),(2,'Pets Allowed','Επιτρέπονται τα κατοικίδια'),(2,'Clear Selected Facilities','Αποεπιλογή όλων των παροχών'),(2,'Save','Αποθήκευση'),(2,'City field cannot be empty!','Το πεδίο Πόλη δεν μπορεί να είναι κενό!'),(2,'Name field cannot be empty!','Το πεδίο Όνομα δεν μπορεί να είναι κενό!'),(2,'Address field cannot be empty!','Το πεδίο Διεύθυνση δεν μπορεί να είναι κενό!'),(2,'At least one phone number must be specified!','Πρέπει να καταχωρήσετε τουλάχιστον έναν αριθμό τηλεφώνου!'),(2,'A contact email must be inserted!','Πρέπει να εισαχθεί ένα email επικοινωνίας!'),(2,'Hotel description cannot be empty!','Η περιγραφή του ξενοδοχείου δεν μπορεί να είναι κενή!'),(2,'You must specify at least one type of room for your hotel!','Πρέπει να ορίσετε τουλάχιστον έναν τύπο δωματίου για το ξενοδοχείο!'),(2,'An error occured. Please contact the site administrator','Συνέβη σφάλμα. Παρακαλώ επικοινωνήστε με τον διαχειριστή του site'),(2,'Hotel already exists!','Το ξενοδοχείο υπάρχει ήδη!'),(2,'WARNING: Invalid file type or empty picture field. The invalid images have been replaced with the default.','ΠΡΟΕΙΔΟΠΟΙΗΣΗ: Μη έγκυρος τύπος φωτογραφίας ή άδειο πεδίο. Οι μη έγκυρες φωτογραφίες αντικαταστάθηκαν με την κενή.'),(2,'WARNING: File size limit exceeded. The exceeding pictures have been replaced with the default.','ΠΡΟΕΙΔΟΠΟΙΗΣΗ: Μη έγκυρο μέγεθος φωτογραφίας. Οι μη έγκυρες φωτογραφίες αντικαταστάθηκαν με την κενή.'),(2,'Hotel Succesfully Added!','Το Ξενοδοχείο προστέθηκε επιτυχώς!'),(2,'Surname field cannot be empty!','Το πεδίο Επίθετο δεν μπορεί να είναι κενό!'),(2,'Search a Hotel','Αναζήτηση Ξενοδοχείου'),(2,'Edit Hotel Information/Prices','Επεξεργασία Ξενοδοχείου/τιμών'),(2,'Remove a Hotel','Διαγραφή Ξενοδοχείου'),(2,'Hotels','Ξενοδοχεία'),(2,'Language','Γλώσσα'),(2,'Search Hotel','Αναζήτηση Ξενοδοχείου'),(2,'Use the name of a hotel (or part of it), the country or the address to get detailed information or edit it.','Χρησιμοποιήστε το όνομα ενός ξενοδοχείου (ή μέρος του), τη χώρα ή τη διεύθυνση για να δείτε περαιτέρω πληροφορίες ή να το επεξεργαστείτε.'),(2,'Select','Επιλέξτε'),(2,'Search','Αναζήτηση'),(2,'No results','Δεν υπάρχουν αποτελέσματα'),(2,'NAME','ΟΝΟΜΑΣΙΑ'),(2,'ADDRESS','ΔΙΕΥΘΥΝΣΗ'),(2,'COUNTRY','ΧΩΡΑ'),(2,'OPTIONS','ΕΠΙΛΟΓΕΣ'),(2,'Edit Hotel','Επεξεργασία'),(2,'Edit Rates','Τιμές'),(2,'View/Edit Bookings','Κρατήσεις'),(2,'Remove Hotel','Διαγραφή'),(2,'Are you sure you want to remove this hotel?','Θέλετε σίγουρα να διαγράψετε το ξενοδοχείο;'),(2,'Hotel Removed Successfully','Το ξενοδοχείο διαγράφηκε επιτυχώς'),(2,'General Rate','Γενική Τιμή'),(2,'Prices for specific days of week (leave blank if its the same everyday)','সপ্তাহের নির্দিষ্ট দিনের জন্য মূল্য (প্রতিদিন একই থাকলে খালি রাখুন)'),(2,'Monday','সোমবার'),(2,'Tuesday','মঙ্গলবার'),(2,'Wednesday','বূধবার'),(2,'Thursday','বৃহঃবার'),(2,'Friday','শুক্রবার'),(2,'Saturday','শনিবার'),(2,'Sunday','রবিবার'),(2,'Room Type','রুমের ধরন'),(2,'Rates','রেট'),(2,'The General Rate cannot be empty!','সাধারন রেট খালি রাখা যাবে না!'),(2,'Hotel rates set succesfully!','হোটেল রেট সফল ভাবে সেট হয়েছে!'),(2,'Bookings','বুকিং'),(2,'View Bookings','বুকিং দেখুন'),(2,'Edit Booking','এডিট বুকিং'),(2,'Add Booking','এড বুকিং'),(2,'View/Edit Comments','কমেন্ট দেখুন বা সম্পাদন করুন'),(2,'Users','ইউজার'),(2,'Add user','ইউজার যুক্ত করুন'),(2,'Remove user','রিমুভ ইউজার'),(2,'Edit user','ইউজার সম্পাদন'),(2,'Hotel Succesfully Edited!','হোটেল সফলভাবে সম্পাদন হয়েছে'),(2,'Cancel','ক্যান্সেল'),(2,'Logout','লগ আউট'),(2,'Surname','নামের শেষ অংশ'),(2,'Phone','ফোন'),(2,'Repeat Password','পাসওয়ার্ড পূনরায় দিন'),(2,'Type','ধরন'),(2,'User','ইউজার'),(2,'Administrator','এইমিনেস্ট্রেটর'),(2,'User added succesfully!','ইউজার সফল ভাবে যুক্ত হয়েছে'),(2,'Sorry, the username or email is already in use! ','দুঃখিত এই আইডি বা ইমেইল ইতোমধ্যেই ব্যাবহার হয়েছে'),(2,'Username field cannot be empty!','ইউজার নাম ফিল্ড খালি রাখা যাবে না'),(2,'Password field cannot be empty!','পাসওয়ার্ড ফিল্ড খালি রাখা যাবে না'),(2,'You havent chosen the type of the account!','একাউন্টের ধরন পছন্দ করেন নাই'),(2,'Password and Repeat Password do not match!','পাসওয়ার্ড ও পূনরায় দেয়া পাসওয়ার্ড মিল নাই'),(2,'Use the username(or part of it), name or surname to get detailed information or edit a user.','বিস্তারিত তথ্য পেতে বা ব্যবহারকারীকে সম্পাদনা করতে ব্যবহারকারীর নাম (বা এর অংশ), নাম বা উপাধি ব্যবহার করুন।'),(2,'Search Users','ইউজার খুজুন'),(2,'User edited succesfully!','ইউজার সম্পাদন সফল!'),(2,'Are you sure you want to remove this user?','নিশ্চিত এই ইউজার কে রিমুভ করতে চান?;'),(2,'Login','লগইন'),(2,'Wrong username or password. ','ভুল ইউজার নাম/পাসওয়ার্ড');
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `language` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `language` (`language`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`id`, `language`) VALUES (1,'English'),(2,'Bangla');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rates`
--

DROP TABLE IF EXISTS `rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rates` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(20) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `default_price` int(4) NOT NULL DEFAULT 0,
  `price_monday` int(4) DEFAULT 0,
  `price_tuesday` int(4) DEFAULT 0,
  `price_wednesday` int(4) DEFAULT 0,
  `price_thursday` int(4) DEFAULT 0,
  `price_friday` int(4) DEFAULT 0,
  `price_saturday` int(4) DEFAULT 0,
  `price_sunday` int(4) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rates`
--

LOCK TABLES `rates` WRITE;
/*!40000 ALTER TABLE `rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ratings` (
  `hotel_id` int(20) NOT NULL,
  `rating` int(20) NOT NULL,
  `totalvotes` int(20) NOT NULL,
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomtypes`
--

DROP TABLE IF EXISTS `roomtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomtypes` (
  `hotel_id` int(20) NOT NULL,
  `rooms_number` int(3) NOT NULL,
  `room_type` varchar(40) NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `minibar` int(11) NOT NULL DEFAULT 0,
  `bathtub` int(11) NOT NULL DEFAULT 0,
  `safe` int(11) NOT NULL DEFAULT 0,
  `tv` int(11) NOT NULL DEFAULT 0,
  `balcony` int(11) NOT NULL DEFAULT 0,
  `radio` int(11) NOT NULL DEFAULT 0,
  `phone` int(11) NOT NULL DEFAULT 0,
  `ac` int(11) NOT NULL DEFAULT 0,
  `bathacc` int(11) NOT NULL DEFAULT 0,
  `wc` int(11) NOT NULL DEFAULT 0,
  `dryer` int(11) NOT NULL DEFAULT 0,
  `desk` int(11) NOT NULL DEFAULT 0,
  `towels` int(11) NOT NULL DEFAULT 0,
  `view` int(11) NOT NULL DEFAULT 0,
  `heating` int(11) NOT NULL DEFAULT 0,
  `picture1` varchar(200) NOT NULL,
  `picture2` varchar(200) NOT NULL,
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomtypes`
--

LOCK TABLES `roomtypes` WRITE;
/*!40000 ALTER TABLE `roomtypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `roomtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `phone` int(20) DEFAULT NULL,
  `country` varchar(100) NOT NULL,
  `username` int(20) NOT NULL,
  `password` int(20) NOT NULL,
  `email` int(100) NOT NULL,
  `role` varchar(13) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`name`, `surname`, `phone`, `country`, `username`, `password`, `email`, `role`) VALUES ('admin','administrator',1234567890,'Greece',0,0,0,'administrator');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'grihayon_hotel1'
--

--
-- Dumping routines for database 'grihayon_hotel1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-04 22:55:14
