<?php
	session_start();
	if(!isset($_GET['hid'])){
		header("Location:index.php");
	}
	if(!isset($_SESSION['to'])||!isset($_SESSION['from'])){
		header("Location:index.php");
	}
	if($_SESSION['to']<=$_SESSION['from']){
		header("Location:index.php");
	}
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$query="DELETE * FROM book WHERE expires<'".date("Y-m-d H:i:s")."'";
	mysql_query($query);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style type="text/css">
#star ul.star { LIST-STYLE: none; MARGIN: 0; PADDING: 0; WIDTH: 85px; HEIGHT: 20px; LEFT: 10px; TOP: -5px; POSITION: relative; FLOAT: left; BACKGROUND: url('img/star.png') repeat-x; CURSOR: pointer; }
#star li { PADDING: 0; MARGIN: 0; FLOAT: left; DISPLAY: block; WIDTH: 85px; HEIGHT: 20px; TEXT-DECORATION: none; text-indent: -9000px; Z-INDEX: 20; POSITION: absolute; PADDING: 0; }
#star li.curr { BACKGROUND: url('img/star.png') left 25px; FONT-SIZE: 1px; }
#star div.user { LEFT: 15px; POSITION: relative; FLOAT: left; FONT-SIZE: 13px; FONT-FAMILY: Arial; COLOR: #888; }
#star {
	padding-left:30px;
}
</style>
<script type="text/javascript" src="js/lightbox.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript">
function getPrice(rooms, rate, target){
	var price=rooms*rate;
	document.getElementById("price"+target).innerHTML=rooms*rate;
}
function $(v,o) { return((typeof(o)=='object'?o:document).getElementById(v)); }
function $S(o) { return((typeof(o)=='object'?o:$(o)).style); }
function agent(v) { return(Math.max(navigator.userAgent.toLowerCase().indexOf(v),0)); }
function abPos(o) { var o=(typeof(o)=='object'?o:$(o)), z={X:0,Y:0}; while(o!=null) { z.X+=o.offsetLeft; z.Y+=o.offsetTop; o=o.offsetParent; }; return(z); }
function XY(e,v) { var o=agent('msie')?{'X':event.clientX+document.body.scrollLeft,'Y':event.clientY+document.body.scrollTop}:{'X':e.pageX,'Y':e.pageY}; return(v?o[v]:o); }

star={};

star.mouse=function(e,o) { if(star.stop || isNaN(star.stop)) { star.stop=0;

	document.onmousemove=function(e) { var n=star.num;
	
		var p=abPos($('star'+n)), x=XY(e), oX=x.X-p.X, oY=x.Y-p.Y; star.num=o.id.substr(4);

		if(oX<1 || oX>84 || oY<0 || oY>19) { star.stop=1; star.revert(); }
		
		else {

			$S('starCur'+n).width=oX+'px';
			$S('starUser'+n).color='#111';
			$('starUser'+n).innerHTML=Math.round(oX/84*100)+'%';
		}
	};
} };

star.update=function(e,o) { var n=star.num, v=parseInt($('starUser'+n).innerHTML);

	n=o.id.substr(4); $('starCur'+n).title=v;

	req=new XMLHttpRequest(); req.open('GET','/AJAX_Star_Vote.php?vote='+(v/100),false); req.send(null);    

};

star.revert=function() { var n=star.num, v=parseInt($('starCur'+n).title);

	$S('starCur'+n).width=Math.round(v*84/100)+'px';
	$('starUser'+n).innerHTML=(v>0?Math.round(v)+'%':'');
	$('starUser'+n).style.color='#888';
	
	document.onmousemove='';

};

star.num=0;
</script>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="css/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<link rel="stylesheet" href="css/lightbox.css" TYPE="text/css">
<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
<?php
	$query="SELECT * FROM roomtypes WHERE hotel_id=".$_GET['hid'];
	$roomsresult=mysql_query($query);
	$roomsnum=mysql_num_rows($roomsresult)-1;
	$query="SELECT * FROM hotel JOIN countries ON hotel.country_id=countries.id JOIN cities ON hotel.city_id=cities.id WHERE hotel_id='".$_GET['hid']."'";
	$result=mysql_query($query);
	$info=mysql_fetch_array($result);
?>
var roomnum=<?php echo $roomsnum;?>;
</script>

</head>

<body>
<div id="maincontent">
	<h1><?php echo $info['name'];?></h1>
	<div id="address">
		<?php echo $info['hotel_address'].",".$info['city'].",".$info['country'];?>
	</div>
	<div id="images" name="images">
		<a href="administrator/images/hotels/<?php echo $info['photo1']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo1']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo2']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo2']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo3']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo3']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo4']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo4']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo5']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo5']?>" height="150" width="150" border="0"></a>
	</div>
	<div class="tabber">
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Description");?></h2>
			<?php echo $info['hotel_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Rooms");?></h2>
			<div>
			<div id="roomsleft">
				<?php echo $info['room_description']?><BR /><BR />
			</div>
			<div style="clear:both"></div>
			</div>
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Area");?></h2>
			<?php echo $info['area_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"How to arrive");?></h2>
			<?php echo $info['travel_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Food");?></h2>
			<?php echo $info['food_description']?><BR /><BR />
		</div>	
		<div class="tabbertab facilities">
			<h2><?php echo get_word($lang,"Facilities");?></h2>
			<?php
				$query="SELECT * FROM hotel_facilities WHERE hotel_id=".$_GET['hid'];
				$result=mysql_query($query);
				$facilities=array();
				$valuesfield="00000000000000000000000";
				$row=mysql_fetch_array($result,MYSQL_NUM);
				foreach($row as $value=>$key){
					if($value!=0){
						if($key==1){
							$valuesfield[$value-1]=$key;
							$facilities[]="_hover";
						}
						else{
							$valuesfield[$value-1]=$key;
							$facilities[]="";
						}
					}
				}
			?>
			<table border="0">
				<tr class="line1">
					<td>
						<div class="hoverbox">
							<img id="airport" src="administrator/images/facilities/airport<?php echo $facilities[0]; ?>.png" alt="Near Airport"/>
							<span><?php echo get_word($lang,"Near Airport");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="baby" src="administrator/images/facilities/baby<?php echo $facilities[1]; ?>.png" alt="Baby Sitting"/>
							<span><?php echo get_word($lang,"Baby Sitting");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="barr" src="administrator/images/facilities/barr<?php echo $facilities[2]; ?>.png" alt="Bar Available"/>
							<span>Bar</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="beach" src="administrator/images/facilities/beach<?php echo $facilities[3]; ?>.png" alt="Near Beach"/>
							<span><?php echo get_word($lang,"Near Beach");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="car_parking" src="administrator/images/facilities/car_parking<?php echo $facilities[4]; ?>.png" alt="Parking Available"/>
							<span>Parking</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="alarm" src="administrator/images/facilities/alarm<?php echo $facilities[5]; ?>.png" alt="Alarm Service"/>
							<span><?php echo get_word($lang,"Alarm Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="Elevator" src="administrator/images/facilities/Elevator<?php echo $facilities[7]; ?>.png" alt="Elevator Available"/>
							<span><?php echo get_word($lang,"Elevator Available");?></span>
						</div>
					</td>
				</tr>
				<tr class="line2">
					<td>
						<div class="hoverbox">
							<img id="entertainment" src="administrator/images/facilities/entertainment<?php echo $facilities[8]; ?>.png" alt="Entertainment Hall"/>
							<span><?php echo get_word($lang,"Entertainment Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="gym" src="administrator/images/facilities/gym<?php echo $facilities[9]; ?>.png" alt="Gym facilities"/>
							<span><?php echo get_word($lang,"Gym Facilities");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="safe" src="administrator/images/facilities/safe<?php echo $facilities[10]; ?>.png" alt="Safe"/>
							<span><?php echo get_word($lang,"In room Safe");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="internet" src="administrator/images/facilities/internet<?php echo $facilities[11]; ?>.png" alt="Internet"/>
							<span>Internet</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="iron" src="administrator/images/facilities/iron<?php echo $facilities[12]; ?>.png" alt="Iron"/>
							<span><?php echo get_word($lang,"In room Iron");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="laundry" src="administrator/images/facilities/laundry<?php echo $facilities[13]; ?>.png" alt="Laundry Service"/>
							<span><?php echo get_word($lang,"Laundry Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="mailbox" src="administrator/images/facilities/mailbox<?php echo $facilities[14]; ?>.png" alt="mailbox"/>
							<span><?php echo get_word($lang,"Mailbox");?></span>
						</div>
					</td>
				</tr>
				<tr class="line3">
					<td>
						<div class="hoverbox">
							<img id="exchange" src="administrator/images/facilities/exchange<?php echo $facilities[15]; ?>.png" alt="Money Exchange"/>
							<span><?php echo get_word($lang,"Money Exchange");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="satellite" src="administrator/images/facilities/satellite<?php echo $facilities[16]; ?>.png" alt="Satellite tv"/>
							<span><?php echo get_word($lang,"Satellite Tv");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="spa" src="administrator/images/facilities/spa<?php echo $facilities[18]; ?>.png" alt="Spa"/>
							<span>Spa</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="conference" src="administrator/images/facilities/conference<?php echo $facilities[6]; ?>.png" alt="Conference Hall"/>
							<span><?php echo get_word($lang,"Conference Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="pool" src="administrator/images/facilities/pool<?php echo $facilities[19]; ?>.png" alt="Swimming Pool"/>
							<span><?php echo get_word($lang,"Swimming Pool");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="heating" src="administrator/images/facilities/heating<?php echo $facilities[20]; ?>.png" alt="Heating"/>
							<span><?php echo get_word($lang,"Heating");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="ac" src="administrator/images/facilities/ac<?php echo $facilities[21]; ?>.png" alt="Air Conditioning"/>
							<span><?php echo get_word($lang,"Air Conditioning");?></span>
						</div>
					</td>
				</tr>
			</table>
			<div class="smokepets">
				<table border=0>
					<tr>
						<td>
							<div class="hoverbox">
								<img id="pets" src="administrator/images/facilities/pets<?php echo $facilities[22]; ?>.png" alt="Pets"/>
								<span><?php echo get_word($lang,"Pets Allowed");?></span>
							</div>
						</td>
						<td>
							<div class="hoverbox">
								<img id="smoking" src="administrator/images/facilities/smoking<?php echo $facilities[17]; ?>.png" alt="Smoking"/>
								<span><?php echo get_word($lang,"Smoking Allowed");?></span>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<input type="hidden" name="facilitiesvalues" id="facilitiesvalues" value="<?php echo $valuesfield;?>">
		</div><BR><BR>
	</div>
	<div id="fields">
		<div id="roomsfields">
		<table width="100%">
			<tr style="font-weight:bold"><td><?php echo get_word($lang,"Room Type")."</td><td>".get_word($lang,"Available Rooms")."</td><td>".get_word($lang,"Price")."</td><td>".get_word($lang,"No of Rooms")."</td>";
			$i=0;
			$roomsbooked=array();
			$ratestable=array();
			$query="SELECT * FROM roomtypes WHERE hotel_id='".$_GET['hid']."'";
			$result=mysql_query($query);
			while($row=mysql_fetch_array($result)){
				$roomsbooked[$row['room_type']]=0;
				for($i=0;$i<8;$i++)
					$ratestable[$row['room_type']][$i]=0;
			}
			$query="SELECT * FROM rates WHERE hotel_id='".$_GET['hid']."'";
			$result=mysql_query($query);
			while($row=mysql_fetch_array($result)){
				$ratestable[$row['room_type']][0]=$row['default_price'];
				$ratestable[$row['room_type']][1]=$row['price_monday'];
				$ratestable[$row['room_type']][2]=$row['price_tuesday'];
				$ratestable[$row['room_type']][3]=$row['price_wednesday'];
				$ratestable[$row['room_type']][4]=$row['price_thursday'];
				$ratestable[$row['room_type']][5]=$row['price_friday'];
				$ratestable[$row['room_type']][6]=$row['price_saturday'];
				$ratestable[$row['room_type']][7]=$row['price_sunday'];
			}
			$from=array();
			$tok=strtok($_SESSION['from'],"-");
			while($tok){
				$from[]=$tok;
				$tok=strtok("-");
			}
			$to=array();
			$tok=strtok($_SESSION['to'],"-");
			while($tok){
				$to[]=$tok;
				$tok=strtok("-");
			}
			$query="SELECT * FROM book WHERE hotel_id='".$_GET['hid']."' AND 
			((check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$from[2]."-".$from[1]."-".$from[0]."') OR
			(check_in>='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out<='".$to[2]."-".$to[1]."-".$to[0]."') OR
			(check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."') OR
			(check_in<'".$to[2]."-".$to[1]."-".$to[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."'))";
			$result=mysql_query($query);
			while($row=mysql_fetch_array($result)){
					$roomsbooked[$row['room_type']]++;
			}
			while(($row=mysql_fetch_array($roomsresult))!=NULL){
				$roomsleft=$row['rooms_number']-$roomsbooked[$row['room_type']];
				echo "<tr><td>".$row['room_type']."</td><td>".$roomsleft."</td>";
				
				$price=0;
				$_SESSION['totaldays']=0;
				$date=strtotime($from[2]."-".$from[1]."-".$from[0]);
				while($date<strtotime($to[2]."-".$to[1]."-".$to[0])){
					$_SESSION['totaldays']++;
					$dayofweek=date("N",$date);
					if($ratestable[$row['room_type']][$dayofweek]!=0)
						$price+=$ratestable[$row['room_type']][$dayofweek];
					else
						$price+=$ratestable[$row['room_type']][0];
					$date+=86400;
				}
				echo "<td><div id=\"price".$row['room_type']."\">".$price."</td></div>";
				?>
				<form name="roomsform" id="roomsform" method="POST" action="bookroom.php?roomtype=<?php echo $row['room_type']."&hid=".$_GET['hid']; ?>">
				<?php
				if($roomsleft<=0)
					$disabled="disabled";
				else
					$disabled="";
				echo "<td><select name=\"numberofrooms".$row['room_type']."\"  style=\"width:40px\" ".$disabled." id=\"numberofrooms".$row['room_type']."\" onchange=\"getPrice(this.value,".$price.",'".$row['room_type']."');\">";
				$_SESSION['price'.$row['room_type']]=$price;
				for($i=1;$i<=$roomsleft;$i++){
					echo "<option value=\"".$i."\">".$i."</option>";
				}
				echo "</select></td>";
				
				echo "<td><input type=\"submit\" ".$disabled." name=\"submit".$row['room_type']."\" id=\"submit".$row['room_type']."\" value=\"".get_word($lang,"Book!")."\"></td>";
				echo "</tr>";
				echo "</form>";
			}
			?>
				
		</table>
		</table>
		</div>
	</div>
	<div style="clear:both"></div>
	<div id="commentsrating">
		<div id="rating">
			<h2 style="padding:0;margin:0;">Rating</h2>
			<div id="ratearea">
				<?php 
					$query="SELECT * FROM ratings WHERE hotel_id='".$_GET['hid']."'";
					$result=mysql_query($query);
					if(mysql_num_rows($result)==0){
						$rating="N/A";
					}else{
						$row=mysql_fetch_array($result);
						$rating=$row['rating']/$row['totalvotes'];
					}
				?>
				<div id="ratepercent"><?php echo $rating;?></div><div id="percentsymbol">%</div>
				<br style="clear:both">
			</div>
			<div id="star">
			<?php 
			if(isset($_SESSION['email'])){
				$query="SELECT * FROM book JOIN users ON book.user_id=users.email WHERE email='".$_SESSION['email']."' AND hotel_id='".$_GET['hid']."'";
				$result=mysql_query($query);
				if(mysql_num_rows($result)!=0){
					echo "
						<ul id=\"star0\" class=\"star\" onmousedown=\"star.update(event,this)\" onmousemove=\"star.mouse(event,this)\" title=\"Rate This!\">
						<li id=\"starCur0\" class=\"curr\" title=\"0\" style=\"width: 0px;\"></li>
						</ul>
						<div style=\"color: rgb(136, 136, 136);\" id=\"starUser0\" class=\"user\">0%</div>
						<br style=\"clear: both;\">
					";
				}else
					echo "You must have stayed in this hotel to rate it";
			}else{
				echo "Please Login to rate";
			}
				
			?>
			</div>
		</div>
		<div id="commentform">
			<h2 style="padding:0;margin:0;">Your Comments</h2><BR>
			Enter your comments below:<BR><BR>
			<?php 
			if(isset($_SESSION['email'])){
				$query="SELECT * FROM book JOIN users ON book.user_id=users.email WHERE email='".$_SESSION['email']."' AND hotel_id='".$_GET['hid']."'";
				$result=mysql_query($query);
				if(mysql_num_rows($result)!=0){
					echo "
						<form name=\"comments\" method=\"post\" action=\"postcomment.php\">
						(Up to 200 characters)<BR>
						<textarea name=\"comment\" id=\"comment\" rows=\"6\" cols=\"75\" style=\"overflow-y:auto\"></textarea>
						<CENTER><input type=\"submit\" name=\"submitcomment\" id=\"submitcomment\" value=\"Submit\"></CENTER>
						</form>
					";
				}else
					echo "You must have stayed in this hotel to leave a comment";
			}else{
				echo "Please Login to comment";
			}
				
			?>
			
		</div>
		<div style="clear:both"></div>
		<div id="commentarea" style="padding:10px;">
			<?php 
				$query="SELECT * FROM comments WHERE hotel_id='".$_GET['hid']."'";
				$result=mysql_query($query);
				if(mysql_num_rows($result)==0){
					echo "No comments posted yet";
				}else{
					while($row=mysql_fetch_array($result)){
						echo $row['comment'];
						echo "<HR>";
					}
				}
			?>
		</div>
	</div>
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
