<?php
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$from=array();
	$tok=strtok($_SESSION['from'],"-");
	while($tok){
		$from[]=$tok;
		$tok=strtok("-");
	}
	$to=array();
	$tok=strtok($_SESSION['to'],"-");
	while($tok){
		$to[]=$tok;
			$tok=strtok("-");
	}
	$query="SELECT * FROM book WHERE hotel_id='".$_GET['hid']."' AND 
	((check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$from[2]."-".$from[1]."-".$from[0]."') OR
	(check_in>='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out<='".$to[2]."-".$to[1]."-".$to[0]."') OR
	(check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."') OR
	(check_in<'".$to[2]."-".$to[1]."-".$to[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."')) AND room_type='".$_SESSION['roomtype']."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		echo "<script type=\"text/javascript\">";
		echo "alert(\"Sorry, no rooms available for these dates!\");";
		echo "window.location=\"index.php\";";
		echo "</script>";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
</head>

<body>
<div id="maincontent">
	You booked:<BR>
	<?php echo $_SESSION['numberofrooms']." ".$_SESSION['roomtype']." room(s) for ".$_SESSION['totalprice']."&euro;<BR>"; ?>
	<?php echo "Dates:".$_SESSION['from']." until ".$_SESSION['to']."<BR>";
		echo "You are:<BR>";
		echo $_POST['name']."<BR>".$_POST['surname']."<BR>".$_POST['phone']."<BR>".$_POST['email']."<BR>".$_POST['country']."<BR>";
		if(isset($_SESSION['email'])){
			echo "(registered user)";
		}
	?>
	<BR>Thank you for your booking!
</div>
<?php
	mysql_close($con);
?>
</body>
</html>
