﻿<?php
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_POST['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$query="SELECT * FROM cities JOIN countries ON cities.country_id=countries.id WHERE country='".$_POST['country']."'";
	$result=mysql_query($query);
	echo "<select name=\"city\" id=\"city\">";
	if(mysql_num_rows($result)==0){
		echo "<option value=\"No Cities Available\">No Cities Available</option>";
	}else{
		while($row=mysql_fetch_array($result)){
			echo "<option value=\"".$row['city']."\">".$row['city']."</option>";
		}
	}
	echo "</select>";
?>