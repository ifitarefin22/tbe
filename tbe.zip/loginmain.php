﻿<?php 
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$query="SELECT * FROM users WHERE email='".$_POST['email']."'AND password='".$_POST['password']."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==1){
		$_SESSION['email']=$_POST['email'];
		$row=mysql_fetch_array($result);
		echo"<h2 style=\"margin:0;padding:0;display:inline\">Welcome</h2><BR><BR><BR>";
			echo $row['name']." ".$row['surname']."<BR><BR>";
			echo "<a href=\"logout.php\">Logout</a>";
	}else{
		echo "
			<h2 style=\"margin:0;padding:0;display:inline\">Login</h2> <BR>
			<table style=\"margin:10px auto;\">
			<tr>
			<td>Email</td>
			<td><input type=\"text\" name=\"email\" id=\"email\"></td>
			</tr>
			<tr>
			<td>Password</td>
			<td><input type=\"password\" name=\"password\" id=\"password\"></td>
			</tr>
			<tr>
			<td></td>
			<td><input type=\"submit\" name=\"submit\" id=\"submit\" value=\"Login\"  onclick=\"login();\"></td>
			</tr>
			</table>
			<span style=\"color:red\">Wrong email or password.</span>
			</div>
			";
	}
?>