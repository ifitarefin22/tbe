﻿<?php 
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
	$query="SELECT * FROM users WHERE email='".$_POST['email']."'AND password='".$_POST['password']."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==1){
		$_SESSION['email']=$_POST['email'];
		$row=mysql_fetch_array($result);
		echo"<h3 id=\"title\">Your Details</h3>
		<table>
				<tr>
					<td>
						Name:
					</td>
					<td>
						<input type=\"text\" id=\"name\" name=\"name\" value=\"".$row['name']."\" readonly>
					</td>
				</tr>
				<tr>
					<td>
						Surname:
					</td>
					<td>
						<input type=\"text\" id=\"surname\" name=\"surname\" value=\"".$row['surname']."\" readonly>
					</td>
				</tr>
				<tr>
					<td>
						Phone:
					</td>
					<td>
						<input type=\"text\" id=\"phone\" name=\"phone\" value=\"".$row['phone']."\" readonly>
					</td>
				</tr>
				<tr>
					<td>
						Email:
					</td>
					<td>
						<input type=\"text\" id=\"email\" name=\"email\" value=\"".$row['email']."\" readonly>
					</td>
				</tr>
				<tr>
					<td>
						Country:
					</td>
					<td>
						<input type=\"text\" id=\"country\" name=\"country\" value=\"".$row['country']."\" readonly>
					</td>
				</tr>
			</table>";
	}else{
		echo "
			<h3 id=\"title\">Login</h3>
			<div id=\"details\" style=\"position:absolute;visibility:hidden\">
				<table>
					<tr>
						<td>
							Name:
						</td>
						<td>
							<input type=\"text\" id=\"name\" name=\"name\">
						</td>
					</tr>
					<tr>
						<td>
							Surname:
						</td>
						<td>
							<input type=\"text\" id=\"surname\" name=\"surname\">
						</td>
					</tr>
					<tr>
						<td>
							Phone:
						</td>
						<td>
							<input type=\"text\" id=\"phone\" name=\"phone\">
						</td>
					</tr>
					<tr>
						<td>
							Email:
						</td>
						<td>
							<input type=\"text\" id=\"email\" name=\"email\">
						</td>
					</tr>
					<tr>
						<td>
							Country:
						</td>
						<td>
							<select name=\"country\" id=\"country\" onchange=\"showResult();\">
								<option>Select</option>";
								
									$query="SELECT * FROM countries";
									$result=mysql_query($query);
									echo mysql_num_rows($result);
									while(($row=mysql_fetch_array($result))!=NULL){
									echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
									}
								
							echo"</select>
						</td>
					</tr>
				</table>
			</div>
			<div id=\"loginform\" hidden=\"true\" style=\"position:absolute;\">
				<table>
					<tr>
						<td>
							Email:
						</td>
						<td>
							<input type=\"text\" name=\"loginemail\" id=\"loginemail\">
						</td>
					</tr>	
					<tr>
						<td>
							Password:
						</td>
						<td>
							<input type=\"password\" name=\"loginpassword\" id=\"loginpassword\">
						</td>
					</tr>
					<tr>
						<td>
						</td>
						<td>
							<input type=\"button\" name=\"loginbutton\" id=\"loginbutton\" value=\"Login\" onclick=\"login();\">
						</td>
					</tr>
				</table>
				<span style=\"color:red\">Wrong email or password.</span>
			</div>
			<div id=\"logintext\" style=\"position:absolute;bottom:0;margin:20px 0;\">If you dont have an account you can just fill in your <a style=\"text-decoration:underline;color:#888;cursor:pointer\" name=\"loginbutton\" onclick=\"showlogin();\">details</a>.</div>
		";
	}
?>