<?php
	session_start();
	if(!isset($_GET['hid'])){
		header("Location:index.php");
	}
	if(!isset($_GET['roomtype'])){
		header("Location:index.php");
	}
	$_SESSION['roomtype']=$_GET['roomtype'];
	$_SESSION['hid']=$_GET['hid'];
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script>
	function showlogin(){
		if(document.getElementById("loginform").style.visibility=="hidden"){
			document.getElementById("loginform").style.visibility="visible";
			document.getElementById("details").style.visibility="hidden";
			document.getElementById("title").innerHTML="Login";
			document.getElementById("logintext").innerHTML='If you dont have an account you can just fill in your <a style="text-decoration:underline;color:#888;cursor:pointer" name="loginbutton" onclick="showlogin();">details</a>.';
		}else{
			document.getElementById("loginform").style.visibility="hidden";
			document.getElementById("details").style.visibility="visible";
			document.getElementById("title").innerHTML="Your Details";
			document.getElementById("logintext").innerHTML='If you already have an account you can <a style="text-decoration:underline;color:#888;cursor:pointer" name="loginbutton" onclick="showlogin();">login</a>.';
		}
	}
	function login(){
	var email=document.getElementById('loginemail').value;
	var password=document.getElementById('loginpassword').value;
	var params = "email="+email+"&password="+password+"&lang=<?php echo $lang;?>";
	http=new XMLHttpRequest();
	
	http.open("POST","login.php",true);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	http.send(params);
	http.onreadystatechange = function() {//Call a function when the state changes.
		if(http.readyState == 4 && http.status == 200){
			document.getElementById("detailslogin").innerHTML=http.responseText;
		}
	}

	
}
</script>
<script type="text/javascript" src="js/lightbox.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $site_title;?></title>
<script type="text/javascript" src="js/tabber.js"></script>
<link rel="stylesheet" href="css/tabber.css" TYPE="text/css">
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<link rel="stylesheet" href="css/lightbox.css" TYPE="text/css">
<script type="text/javascript">

/* Optional: Temporarily hide the "tabber" class so it does not "flash"
   on the page as plain HTML. After tabber runs, the class is changed
   to "tabberlive" and it will appear. */

document.write('<style type="text/css">.tabber{display:none;}<\/style>');
<?php
	$query="SELECT * FROM roomtypes WHERE hotel_id=".$_GET['hid'];
	$roomsresult=mysql_query($query);
	$roomsnum=mysql_num_rows($roomsresult)-1;
	$query="SELECT * FROM hotel JOIN countries ON hotel.country_id=countries.id JOIN cities ON hotel.city_id=cities.id WHERE hotel_id='".$_GET['hid']."'";
	$result=mysql_query($query);
	$info=mysql_fetch_array($result);
?>
var roomnum=<?php echo $roomsnum;?>;
</script>

</head>

<body>
<div id="maincontent">
	<h1><?php echo $info['name'];?></h1>
	<div id="address">
		<?php echo $info['hotel_address'].",".$info['city'].",".$info['country'];?>
	</div>
	<div id="images" name="images">
		<a href="administrator/images/hotels/<?php echo $info['photo1']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo1']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo2']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo2']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo3']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo3']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo4']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo4']?>" height="150" width="150" border="0"></a>
		<a href="administrator/images/hotels/<?php echo $info['photo5']?>" rel="lightbox"><img src="administrator/images/hotels/<?php echo $info['photo5']?>" height="150" width="150" border="0"></a>
	</div>
	<div class="tabber">
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Description");?></h2>
			<?php echo $info['hotel_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Rooms");?></h2>
			<div>
			<div id="roomsleft">
				<?php echo $info['room_description']?><BR /><BR />
			</div>
			<div style="clear:both"></div>
			</div>
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Area");?></h2>
			<?php echo $info['area_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"How to arrive");?></h2>
			<?php echo $info['travel_description']?><BR /><BR />
		</div>
		<div class="tabbertab">
			<h2><?php echo get_word($lang,"Food");?></h2>
			<?php echo $info['food_description']?><BR /><BR />
		</div>	
		<div class="tabbertab facilities">
			<h2><?php echo get_word($lang,"Facilities");?></h2>
			<?php
				$query="SELECT * FROM hotel_facilities WHERE hotel_id=".$_GET['hid'];
				$result=mysql_query($query);
				$facilities=array();
				$valuesfield="00000000000000000000000";
				$row=mysql_fetch_array($result,MYSQL_NUM);
				foreach($row as $value=>$key){
					if($value!=0){
						if($key==1){
							$valuesfield[$value-1]=$key;
							$facilities[]="_hover";
						}
						else{
							$valuesfield[$value-1]=$key;
							$facilities[]="";
						}
					}
				}
			?>
			<table border="0">
				<tr class="line1">
					<td>
						<div class="hoverbox">
							<img id="airport" src="administrator/images/facilities/airport<?php echo $facilities[0]; ?>.png" alt="Near Airport"/>
							<span><?php echo get_word($lang,"Near Airport");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="baby" src="administrator/images/facilities/baby<?php echo $facilities[1]; ?>.png" alt="Baby Sitting"/>
							<span><?php echo get_word($lang,"Baby Sitting");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="barr" src="administrator/images/facilities/barr<?php echo $facilities[2]; ?>.png" alt="Bar Available"/>
							<span>Bar</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="beach" src="administrator/images/facilities/beach<?php echo $facilities[3]; ?>.png" alt="Near Beach"/>
							<span><?php echo get_word($lang,"Near Beach");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="car_parking" src="administrator/images/facilities/car_parking<?php echo $facilities[4]; ?>.png" alt="Parking Available"/>
							<span>Parking</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="alarm" src="administrator/images/facilities/alarm<?php echo $facilities[5]; ?>.png" alt="Alarm Service"/>
							<span><?php echo get_word($lang,"Alarm Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="Elevator" src="administrator/images/facilities/Elevator<?php echo $facilities[7]; ?>.png" alt="Elevator Available"/>
							<span><?php echo get_word($lang,"Elevator Available");?></span>
						</div>
					</td>
				</tr>
				<tr class="line2">
					<td>
						<div class="hoverbox">
							<img id="entertainment" src="administrator/images/facilities/entertainment<?php echo $facilities[8]; ?>.png" alt="Entertainment Hall"/>
							<span><?php echo get_word($lang,"Entertainment Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="gym" src="administrator/images/facilities/gym<?php echo $facilities[9]; ?>.png" alt="Gym facilities"/>
							<span><?php echo get_word($lang,"Gym Facilities");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="safe" src="administrator/images/facilities/safe<?php echo $facilities[10]; ?>.png" alt="Safe"/>
							<span><?php echo get_word($lang,"In room Safe");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="internet" src="administrator/images/facilities/internet<?php echo $facilities[11]; ?>.png" alt="Internet"/>
							<span>Internet</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="iron" src="administrator/images/facilities/iron<?php echo $facilities[12]; ?>.png" alt="Iron"/>
							<span><?php echo get_word($lang,"In room Iron");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="laundry" src="administrator/images/facilities/laundry<?php echo $facilities[13]; ?>.png" alt="Laundry Service"/>
							<span><?php echo get_word($lang,"Laundry Service");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="mailbox" src="administrator/images/facilities/mailbox<?php echo $facilities[14]; ?>.png" alt="mailbox"/>
							<span><?php echo get_word($lang,"Mailbox");?></span>
						</div>
					</td>
				</tr>
				<tr class="line3">
					<td>
						<div class="hoverbox">
							<img id="exchange" src="administrator/images/facilities/exchange<?php echo $facilities[15]; ?>.png" alt="Money Exchange"/>
							<span><?php echo get_word($lang,"Money Exchange");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="satellite" src="administrator/images/facilities/satellite<?php echo $facilities[16]; ?>.png" alt="Satellite tv"/>
							<span><?php echo get_word($lang,"Satellite Tv");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="spa" src="administrator/images/facilities/spa<?php echo $facilities[18]; ?>.png" alt="Spa"/>
							<span>Spa</span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="conference" src="administrator/images/facilities/conference<?php echo $facilities[6]; ?>.png" alt="Conference Hall"/>
							<span><?php echo get_word($lang,"Conference Hall");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="pool" src="administrator/images/facilities/pool<?php echo $facilities[19]; ?>.png" alt="Swimming Pool"/>
							<span><?php echo get_word($lang,"Swimming Pool");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="heating" src="administrator/images/facilities/heating<?php echo $facilities[20]; ?>.png" alt="Heating"/>
							<span><?php echo get_word($lang,"Heating");?></span>
						</div>
					</td>
					<td>
						<div class="hoverbox">
							<img id="ac" src="administrator/images/facilities/ac<?php echo $facilities[21]; ?>.png" alt="Air Conditioning"/>
							<span><?php echo get_word($lang,"Air Conditioning");?></span>
						</div>
					</td>
				</tr>
			</table>
			<div class="smokepets">
				<table border=0>
					<tr>
						<td>
							<div class="hoverbox">
								<img id="pets" src="administrator/images/facilities/pets<?php echo $facilities[22]; ?>.png" alt="Pets"/>
								<span><?php echo get_word($lang,"Pets Allowed");?></span>
							</div>
						</td>
						<td>
							<div class="hoverbox">
								<img id="smoking" src="administrator/images/facilities/smoking<?php echo $facilities[17]; ?>.png" alt="Smoking"/>
								<span><?php echo get_word($lang,"Smoking Allowed");?></span>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<input type="hidden" name="facilitiesvalues" id="facilitiesvalues" value="<?php echo $valuesfield;?>">
		</div><BR><BR>
	</div>
	<div id="credentials" style="height:170px">
		You are about to book <?php echo $_POST['numberofrooms'.$_GET['roomtype']]." ".$_GET['roomtype'];?> room(s) for this hotel at the rate of 
		<?php
			$_SESSION['totalprice']=$_POST['numberofrooms'.$_GET['roomtype']]*$_SESSION['price'.$_GET['roomtype']];
			echo $_SESSION['totalprice']."&euro; (".$_SESSION['price'.$_GET['roomtype']]."&euro; per room per night)";?>  .
		<?php 
			$_SESSION['numberofrooms']=$_POST['numberofrooms'.$_GET['roomtype']];
			if(isset($_SESSION['email'])){
				$query="SELECT * FROM users WHERE email='".$_SESSION['email']."'";
				$result=mysql_query($query);
				$row=mysql_fetch_array($result);
			}
		?>
		<div id="detailslogin" style="position:relative;height:210px">
		<form name="loginformdetails" method="POST" action="bookfinal.php">
			<h3 id="title"style="margin-top:10px;">Your Details</h3>
			<div id="details" style="position:absolute">
				<table>
					<tr>
						<td>
							Name:
						</td>
						<td>
							<input type="text" id="name" name="name" <?php if(isset($_SESSION['email'])) echo "readonly value=\"".$row['name']."\""; ?>>
						</td>
					</tr>
					<tr>
						<td>
							Surname:
						</td>
						<td>
							<input type="text" id="surname" name="surname" <?php if(isset($_SESSION['email'])) echo "readonly value=\"".$row['surname']."\""; ?>>
						</td>
					</tr>
					<tr>
						<td>
							Phone:
						</td>
						<td>
							<input type="text" id="phone" name="phone" <?php if(isset($_SESSION['email'])) echo "readonly value=\"".$row['phone']."\""; ?>>
						</td>
					</tr>
					<tr>
						<td>
							Email:
						</td>
						<td>
							<input type="text" id="email" name="email" <?php if(isset($_SESSION['email'])) echo "readonly value=\"".$row['email']."\""; ?>>
						</td>
					</tr>
					<tr>
						<td>
							Country:
						</td>
						<td>
							<?php 
								if(isset($_SESSION['email'])) 
									echo "<input type=\"text\" id=\"country\" name=\"country\" value=\"".$row['country']."\" readonly>"; 
								else{
									echo "<select name=\"country\" id=\"country\" onchange=\"showResult();\">
										  <option>Select</option>";
									$query="SELECT * FROM countries";
									$result=mysql_query($query);
									echo mysql_num_rows($result);
									while(($row=mysql_fetch_array($result))!=NULL){
									echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
									}
									echo "</select>";
								}
							?>
							
						</td>
					</tr>
				</table>
			</div>
			<div id="loginform" hidden="true" style="position:absolute;visibility:hidden">
				<table>
					<tr>
						<td>
							Email:
						</td>
						<td>
							<input type="text" name="loginemail" id="loginemail">
						</td>
					</tr>	
					<tr>
						<td>
							Password:
						</td>
						<td>
							<input type="password" name="loginpassword" id="loginpassword">
						</td>
					</tr>
					<tr>
						<td>
						</td>
						<td>
							<input type="button" name="loginbutton" id="loginbutton" value="Login" onclick="login();">
						</td>
					</tr>
				</table>
			</div>
			<?php
			if(!isset($_SESSION['email'])){
				echo "<div id=\"logintext\" style=\"position:absolute;bottom:0;margin:20px 0;\">If you already have an account you can <a style=\"text-decoration:underline;color:#888;cursor:pointer\" name=\"loginbutton\" onclick=\"showlogin();\">login</a>.</div>";
			}
			?>
		</div>
		<table>
			<tr>
				<td>
					Credit Card Number:
				</td>
				<td>
					<input type="text" name="creditcard" id="creaditcard">
				</td>
			</tr>	
			<tr>
				<td>
					CVV:
				</td>
				<td>
					<input type="text" name="cvv" id="cvv">
				</td>
			</tr>
			<tr>
				<td>
					Expiration Date:
				</td>
				<td>
					<select name="expmonth" id="expmonth">
						<?php 
							for ($i=1;$i<13;$i++)
								echo "<option value=\"".$i."\">".$i."</option>";
						?>
					</select>
					<select name="expyear" id="expyear">
						<?php 
							for ($i=2011;$i<2030;$i++)
								echo "<option value=\"".$i."\">".$i."</option>";
						?>
					</select>
				</td>
			</tr>
			<tr>
		</table>
		<input type="submit" name="submit" id="submit" value="Submit">
		</form>
	</div>
		
	
</div>
<?php
	$from=array();
	$tok=strtok($_SESSION['from'],"-");
	while($tok){
		$from[]=$tok;
		$tok=strtok("-");
	}
	$to=array();
	$tok=strtok($_SESSION['to'],"-");
	while($tok){
		$to[]=$tok;
			$tok=strtok("-");
	}
	$query="SELECT * FROM book WHERE hotel_id='".$_GET['hid']."' AND 
	((check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$from[2]."-".$from[1]."-".$from[0]."') OR
	(check_in>='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out<='".$to[2]."-".$to[1]."-".$to[0]."') OR
	(check_in<='".$from[2]."-".$from[1]."-".$from[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."') OR
	(check_in<'".$to[2]."-".$to[1]."-".$to[0]."' AND check_out>='".$to[2]."-".$to[1]."-".$to[0]."')) AND room_type='".$_SESSION['roomtype']."'";
	$result=mysql_query($query);
	if(mysql_num_rows($result)==0){
		echo "<script type=\"text/javascript\">";
		echo "alert(\"Sorry, no rooms available for these dates!\");";
		echo "window.location=\"index.php\";";
		echo "</script>";
	}
	for($i=0;$i<(int)$_POST['numberofrooms'.$_GET['roomtype']];$i++){
	$query="INSERT INTO book VALUES (".$_GET['hid'].",'temp', '".$_SESSION['roomtype']."', '".$to[2]."-".$to[1]."-".$to[0]."', '".$from[2]."-".$from[1]."-".$from[0]."', '".date("Y-m-d H:i:s",(time()+1800))."')";
	mysql_query($query);
	}
	mysql_close($con);
?>
</body>
</html>
