﻿<?php
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	$_SESSION['from']=$_POST['from'];
	$_SESSION['to']=$_POST['to'];
	//end of set language
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body>
<div id="maincontent" name="maincontent">
	<?php
		$query="SELECT id FROM countries WHERE country='".$_POST['country']."'";
		$result=mysql_query($query);
		$row=mysql_fetch_array($result);
		$country_id=$row['id'];
		$query="SELECT id FROM cities WHERE city='".$_POST['city']."'";
		$result=mysql_query($query);
		$row=mysql_fetch_array($result);
		$city_id=$row['id'];
		$query="SELECT * FROM hotel WHERE city_id='".$city_id."' AND country_id='".$country_id."'";
		$result=mysql_query($query);
		while ($row=mysql_fetch_array($result)){
			echo "<div id=\"hotel\" name=\"hotel\">";
			echo "<a href=\"gethotel?hid=".$row['hotel_id']."&from=".$_POST['from']."&to=".$_POST['to']."\"><h1>".$row['name']."</h1></a> <input type=\"button\" name=\"gethotel\" id=\"gethotel\" value=\"More info & availability\" onclick=\"window.location='gethotel.php?hid=".$row['hotel_id']."&from=".$_POST['from']."&to=".$_POST['to']."'\"><BR><BR>";
			for ($i=1;$i<6;$i++){
				echo "<div id=\"image\" name=\"image\">";
				echo "<img src=\"administrator/images/hotels/".$row['photo'.$i]."\" height=\"125\">";
				echo "</div>";
			}
			echo "<div style=\"clear:both\"></div>";
			echo "<div id=\"hoteldescription\" name=\"hoteldescription\">".$row['hotel_description']."</div>";
			$query="SELECT * FROM roomtypes JOIN rates ON roomtypes.room_type=rates.room_type WHERE roomtypes.hotel_id='"
					.$row['hotel_id']."' AND rates.hotel_id='".$row['hotel_id']."'";
			$resultrooms=mysql_query($query);
			if(mysql_num_rows($resultrooms)>0){
				echo "<div id=\"prices\" name=\"prices\">";
				echo "<table width=\"100%\">";
				echo "<tr>";
				echo "<td width=\"50%\"><B>Room Type</B></td><td><B>Price</B></td>";
				echo "</tr>";
				while($roomrow=mysql_fetch_array($resultrooms)){
					echo "<tr>";
					echo "<td width=\"50%\">".$roomrow['room_type']."</td><td>From ".$roomrow['default_price']."&euro;</td>";
					echo "</tr>";
				}
				echo "</table>";
				echo "</div>";
			}
			echo "</div>";
		}
	?>
</div>
</body>
</html>
