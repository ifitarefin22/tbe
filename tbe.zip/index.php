﻿<?php
	session_start();
	include "includes/configuration.php";
	$con=mysql_connect($location,$username,$password);
	mysql_select_db($database_name);
	mysql_set_charset('utf8',$con);
	include "includes/database_add.php";
	include "includes/language.php";
	//Set language
	if(isset($_GET['lang'])){
		$_SESSION['lang']=$_GET['lang'];
		$lang=$_SESSION['lang'];
	}else if(isset($_SESSION['lang'])){
		$lang=$_SESSION['lang'];
	}else{
		$lang="English";
	}
	//end of set language
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="css/addhotel.css" TYPE="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script type="text/javascript">
	function showResult(){
		var country=document.getElementById('country').value;
		var params = "&country="+country+"&lang=<?php echo $lang;?>";
		http=new XMLHttpRequest();
		http.open("POST","getcity.php",true);
		http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
		http.send(params);
		http.onreadystatechange = function() {//Call a function when the state changes.
			if(http.readyState == 4 && http.status == 200){
				document.getElementById("citydiv").innerHTML=http.responseText;
			}
			if(document.getElementById('city').value!=="No Cities Available")
				document.searchhotel.city.disabled=false;
			else
				document.searchhotel.city.disabled=true;
		}
	}
	<!----Javascript for checking for empty fields icons---!>
	function checkFields(){
		if(document.getElementById("country").value=="<?php echo get_word($lang,"Select");?>"){
			alert("<?php echo get_word($lang,"You must select a country!");?>");
			document.getElementById("country").focus();
			return false;
		}else if(document.getElementById("city").value=="<?php echo get_word($lang,"No Cities Available");?>"){
			alert("<?php echo get_word($lang,"City field cannot be empty!");?>");
			return false;
		}else if(document.getElementById("from").value==""){
			alert("<?php echo get_word($lang,"You must select the check in date!");?>");
			document.getElementById("from").focus();
			return false;
		}else if(document.getElementById("to").value==""){
			alert("<?php echo get_word($lang,"You must select the checkout date!");?>");
			document.getElementById("to").focus();
			return false;
		}else if(document.getElementById("to").value<=document.getElementById("from").value){
			alert("<?php echo get_word($lang,"Checkout date must be later than the checkin date!");?>");
			document.getElementById("to").focus();
			return false;
		}else if(document.getElementById("from").value<="<?php echo date("d-m-Y");?>"){
			alert("<?php echo get_word($lang,"Checkin date must be later than today!");?>");
			document.getElementById("to").focus();
			return false;
		}else{
			return true;
		}
	}
	function login(){
	var email=document.getElementById('email').value;
	var password=document.getElementById('password').value;
	var params = "email="+email+"&password="+password+"&lang=<?php echo $lang;?>";
	http=new XMLHttpRequest();
	
	http.open("POST","loginmain.php",true);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
	http.send(params);
	http.onreadystatechange = function() {//Call a function when the state changes.
		if(http.readyState == 4 && http.status == 200){
			document.getElementById("welcometext").innerHTML=http.responseText;
		}
	}

	
}
</script>
	<script language="JavaScript" src="js/calendar_eu.js"></script>
	<link rel="stylesheet" href="css/calendar.css">
</head>
<body>
<div id="maincontent" name="maincontent">
	<div id="logo" name="logo">
		<img src="img/logo.png">
	</div>
	<div id="searchbox" name="searchbox">
		<form name="searchhotel" method="post" action="searchresults.php" onsubmit="return checkFields();">
			<table border=0 width="330">
				<tr>
					<td>
						Country:
					</td>
					<td>
						<select name="country" id="country" onchange="showResult();">
							<option>Select</option>
							<?php
								$query="SELECT * FROM countries";
								$result=mysql_query($query);
								echo mysql_num_rows($result);
								while(($row=mysql_fetch_array($result))!=NULL){
								echo "<option value=\"".$row['country']."\">".$row['country']."</option>";
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						City:
					</td>
					<td>
						<div id="citydiv" name="citydiv">
						<select name="city" id="city" disabled>
							<option>No Cities Available</option>
						</select>
						</div>
					</td>
				</tr>
				<tr>
					<td>
					From:
					</td>
					<td>
					<input type="text" name="from" id="from" readonly>
					<script language="JavaScript">
						new tcal ({
							'formname': 'searchhotel',
							'controlname': 'from'
						});
					</script>
					</td>
				</tr>
				<tr>
					<td>
					To:
					</td>
					<td>
					<input type="text" name="to" id="to" readonly>
					<script language="JavaScript">
						new tcal ({
							'formname': 'searchhotel',
							'controlname': 'to'
						});
					</script>
					</td>
				</tr>
				<tr>
					<td>
					</td>
					<td>
						<input type="submit" name="submit" id="submit" value="Search" onclick="">
					</td>
				</tr>
			</table>
		</form>
	</div>
	
	<div style="clear:both"></div>
	<div id="toprated" name="toprated">
		<h1 style="padding:10px;margin:0">Top Rated</h1>
	</div>
	<div id="footer" name="footer">
		Prepared by Ifti Arefin 
	</div>
</div>
</body>
</html>
