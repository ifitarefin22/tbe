<?php
$gets="?";
foreach($_GET as $key=>$value){
	$gets.=$key."=".$value."&";
}
$greekselect="";
$englishselect="";
if(isset($_SESSION['lang'])){
	if($_SESSION['lang']=="Greek"){
		$imgsrc="images/flags/Greece-Flag.png";
		$greekselect="selected";
	}
	else if($_SESSION['lang']=="English"){
		$imgsrc="images/flags/United-Kingdom-Flag.png";
		$englishselect="selected";
	}
}
else{
	$imgsrc="images/flags/United-Kingdom-Flag.png";
	$englishselect="selected";
}
?>
<script>
function gotoaddress(fieldvalue){
	window.location="<?php echo $gets;?>lang="+fieldvalue;

	
}
</script>
<table border=0 cellpadding=0 cellspacing=0>
	<tr>
		<td>
			<?php echo get_word($lang,"Language");?>&nbsp;
		</td>
		<td>
			<img src="<?php echo $imgsrc;?>" align="left" height="20">
			<select id="languagedropdown" onchange="gotoaddress(this.options[this.selectedIndex].value)">
				<option <?php echo $greekselect;?> value="Greek">Greek</option>
				<option <?php echo $englishselect;?> value="English">English</option>
			</select>
		</td>
	</tr>
</table>